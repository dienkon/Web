// ============================================================
// 1. IMPORTS & KHỞI TẠO FIREBASE
// ============================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  sendEmailVerification,
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  getDocs,
  getDoc,
  addDoc,
  setDoc,
  writeBatch,
  serverTimestamp,
  deleteField,
  doc,
  documentId,
  updateDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  getCountFromServer,
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import {
  initializePndAppCheck,
  userHasAdminClaim,
} from "./firebase-security.js?v=5.33.4";

// Cấu hình Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDJu0I8tPq88gDDzjD53CkAPKlPl4Vd9Zs",
  authDomain: "pndteam-ac43b.firebaseapp.com",
  projectId: "pndteam-ac43b",
  storageBucket: "pndteam-ac43b.firebasestorage.app",
  messagingSenderId: "504130270745",
  appId: "1:504130270745:web:786924d35bc84ef3d11c88",
  measurementId: "G-E205P0Q75Q",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// App Check
initializePndAppCheck(app);

// ============================================================
// 2. BIẾN TOÀN CỤ & TRẠNG THÁI
// ============================================================

let authTab = "login"; // "login" hoặc "register"
let redirectAfterAuth = ""; // Trang chuyển sau đăng nhập
let katexLoadedPromise = null; // Promise tải KaTeX
let chartInstance = null; // Biểu đồ Chart.js
let chartLoadPromise = null;

window.pndHasAdminRole = false;

// Cache cho Firestore với TTL
const cacheStore = {
  khoDe: {
    snapshot: null,
    loadedAt: 0,
    promise: null,
    cursor: null,
    hasMore: true,
    records: [],
  },
  ketQua: { snapshot: null, loadedAt: 0, promise: null },
  phien: { snapshot: null, loadedAt: 0, promise: null },
};
let currentUid = "";

// Tên collection, prefix
const METADATA_KEY = "pnd_exam_metadata_v5_28";
const CONTENT_PREFIX = "pnd_exam_content_v5_28_";

// ============================================================
// 3. HÀM TIỆN ÍCH
// ============================================================

/** Kiểm tra cache còn hiệu lực (TTL mặc định 60s) */
function isCacheValid(cache, ttlMs = 60000) {
  return Boolean(cache.snapshot && Date.now() - cache.loadedAt < ttlMs);
}

/** Tạo đối tượng QuerySnapshot giả từ mảng dữ liệu (dùng cho cache offline) */
function makeFakeSnapshot(docs = [], fromLocal = false) {
  const items = docs.map((d) => ({ id: d.id, data: d.data || {} }));
  return {
    fromLocalCache: fromLocal,
    size: items.length,
    empty: items.length === 0,
    docs: items.map((d) => ({ id: d.id, data: () => d.data })),
    forEach(callback) {
      items.forEach((d) => callback({ id: d.id, data: () => d.data || {} }));
    },
  };
}

/** Lưu nội dung đề vào localStorage */
function cacheExamContent(examId, content) {
  if (!examId || !content?.questions) return;
  try {
    const payload = JSON.stringify({ savedAt: Date.now(), content });
    if (payload.length > 1_800_000) return; // quá lớn, bỏ qua
    localStorage.setItem(`${CONTENT_PREFIX}${examId}`, payload);
  } catch (e) {
    console.warn(`Không cache được nội dung đề ${examId}:`, e.message);
  }
}

/** Wrapper retry cho các tác vụ Firestore */
async function withRetry(fn, label) {
  try {
    return await fn();
  } catch (err) {
    const code = String(err?.code || "");
    if (code.includes("permission-denied") || code.includes("unauthenticated"))
      throw err;
    await new Promise((res) => setTimeout(res, 450));
    try {
      return await fn();
    } catch (e) {
      console.warn(`${label} thất bại sau khi thử lại:`, e.message);
      throw e;
    }
  }
}

/** Reset cache theo uid */
function resetUserCache(uid) {
  if (currentUid !== uid) {
    currentUid = uid;
    ["ketQua", "phien"].forEach((key) => {
      cacheStore[key] = { snapshot: null, loadedAt: 0, promise: null };
    });
  }
}

/** Chuyển đổi lỗi Firebase thành thông báo tiếng Việt */
function getAuthErrorMessage(error) {
  const code = String(error?.code || "");
  if (
    code.includes("invalid-credential") ||
    code.includes("wrong-password") ||
    code.includes("user-not-found")
  )
    return "Email hoặc mật khẩu chưa đúng.";
  if (code.includes("email-already-in-use"))
    return "Email này đã được đăng ký. Hãy đăng nhập hoặc dùng email khác.";
  if (code.includes("invalid-email"))
    return "Địa chỉ email chưa đúng định dạng.";
  if (code.includes("weak-password")) return "Mật khẩu cần ít nhất 8 ký tự.";
  if (code.includes("too-many-requests"))
    return "Bạn thao tác quá nhiều lần. Hãy thử lại sau ít phút.";
  if (code.includes("network-request-failed"))
    return "Không có kết nối mạng. Hãy kiểm tra Internet.";
  return "Không thể thực hiện lúc này. Vui lòng thử lại.";
}

/** Xử lý lỗi cập nhật tài khoản */
function getAccountErrorMessage(error) {
  const code = String(error?.code || "");
  if (code.includes("wrong-password") || code.includes("invalid-credential"))
    return "Mật khẩu hiện tại không đúng.";
  if (code.includes("weak-password")) return "Mật khẩu mới chưa đủ mạnh.";
  if (code.includes("too-many-requests"))
    return "Bạn thao tác quá nhiều lần. Hãy chờ một lúc rồi thử lại.";
  if (code.includes("network-request-failed"))
    return "Không có kết nối mạng. Hãy kiểm tra Internet.";
  if (code.includes("requires-recent-login"))
    return "Phiên đăng nhập đã cũ. Hãy đăng xuất, đăng nhập lại rồi thử tiếp.";
  return error?.message || "Không thể cập nhật tài khoản.";
}

// ============================================================
// 4. QUẢN LÝ THÔNG BÁO & THÔNG BÁO ĐẾN NGƯỜI DÙNG
// ============================================================

/** Lấy key lưu trạng thái đã đọc thông báo */
function getNotificationReadKey() {
  return auth.currentUser
    ? `pnd_notifications_read_${auth.currentUser.uid}`
    : "";
}

/** Lấy tập hợp các ID thông báo đã đọc */
function getReadNotifications() {
  const key = getNotificationReadKey();
  if (!key) return new Set();
  try {
    const data = JSON.parse(localStorage.getItem(key) || "[]");
    return new Set(Array.isArray(data) ? data : []);
  } catch {
    return new Set();
  }
}

/** Lưu trạng thái đã đọc */
function saveReadNotifications(set) {
  const key = getNotificationReadKey();
  if (key) {
    localStorage.setItem(key, JSON.stringify(Array.from(set).slice(-500)));
  }
}

/** Render danh sách thông báo trong panel */
window.renderTrungTamThongBao = function () {
  const list = document.getElementById("notification-list");
  const countEl = document.getElementById("notification-unread-count");
  if (!list || !countEl) return;

  const readSet = getReadNotifications();
  const notifications = Array.isArray(window.danhSachThongBao)
    ? window.danhSachThongBao
    : [];
  const unread = notifications.filter((n) => !readSet.has(n.id)).length;

  countEl.textContent = unread > 99 ? "99+" : String(unread);
  countEl.classList.toggle("hidden", unread === 0);
  countEl.classList.toggle("flex", unread > 0);

  if (auth.currentUser) {
    if (notifications.length) {
      list.innerHTML = notifications
        .map((n) => {
          const isUnread = !readSet.has(n.id);
          return `
          <button type="button" onclick="moThongBaoKetQua('${encodeURIComponent(n.id)}','${encodeURIComponent(n.docId)}')"
            class="w-full text-left px-4 py-3 border-b border-slate-50 last:border-0 transition ${
              isUnread
                ? "bg-amber-50/70 hover:bg-amber-50"
                : "bg-white hover:bg-slate-50"
            }">
            <div class="flex gap-3">
              <span class="w-10 h-10 shrink-0 rounded-xl flex items-center justify-center ${
                n.loai === "answers"
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-blue-100 text-blue-700"
              }">
                <i class="fas ${n.loai === "answers" ? "fa-key" : "fa-check"}"></i>
              </span>
              <span class="min-w-0 flex-1">
                <span class="flex items-start justify-between gap-2">
                  <strong class="text-sm text-slate-800">${escapeHtml(n.tieuDe)}</strong>
                  ${isUnread ? '<i class="w-2 h-2 rounded-full bg-red-500 shrink-0 mt-1.5"></i>' : ""}
                </span>
                <span class="block text-xs text-slate-500 mt-0.5 line-clamp-2">${escapeHtml(n.noiDung)}</span>
                <span class="block text-[10px] text-slate-400 mt-1">${formatTimeAgo(n.millis)}</span>
              </span>
            </div>
          </button>
        `;
        })
        .join("");
    } else {
      list.innerHTML =
        '<div class="p-8 text-center text-sm text-slate-400"><i class="far fa-bell text-2xl mb-3 block"></i>Chưa có thông báo mới.</div>';
    }
  } else {
    list.innerHTML =
      '<div class="p-8 text-center text-sm text-slate-400"><i class="fas fa-bell-slash text-2xl mb-3 block"></i>Đăng nhập để xem thông báo.</div>';
  }
};

// Các hàm helper được gọi trong render
function escapeHtml(text) {
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
  };
  return String(text).replace(/[&<>'"]/g, (c) => map[c]);
}

function formatTimeAgo(timestamp) {
  if (!timestamp) return "Gần đây";
  const now = Date.now();
  const diff = now - timestamp;
  if (diff >= 0 && diff < 60000) return "Vừa xong";
  if (diff >= 0 && diff < 3600000)
    return `${Math.max(1, Math.floor(diff / 60000))} phút trước`;
  if (diff >= 0 && diff < 86400000)
    return `${Math.floor(diff / 3600000)} giờ trước`;
  return new Date(timestamp).toLocaleString("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

// ============================================================
// 5. XÁC THỰC (AUTH) – ĐĂNG NHẬP, ĐĂNG KÝ, QUÊN MẬT KHẨU
// ============================================================

window.moAuthModal = function (tab = "login", reason = "", redirect = "") {
  authTab = tab === "register" ? "register" : "login";
  if (redirect) redirectAfterAuth = redirect;

  const modal = document.getElementById("auth-modal");
  const reasonEl = document.getElementById("auth-modal-reason");
  if (reasonEl)
    reasonEl.textContent =
      reason || "Tài khoản giúp lưu bài làm và bảo vệ kết quả của bạn.";

  updateAuthTabs();
  modal?.classList.add("is-open");
  document.body.classList.add("auth-open");
  setTimeout(
    () =>
      document
        .getElementById(
          authTab === "login" ? "auth-login-email" : "auth-register-name",
        )
        ?.focus(),
    0,
  );
};

window.dongAuthModal = function () {
  document.getElementById("auth-modal")?.classList.remove("is-open");
  document.body.classList.remove("auth-open");
  redirectAfterAuth = "";
};

// Sự kiện chuyển tab Login/Register
document.getElementById("auth-tab-login")?.addEventListener("click", () => {
  authTab = "login";
  updateAuthTabs();
});
document.getElementById("auth-tab-register")?.addEventListener("click", () => {
  authTab = "register";
  updateAuthTabs();
});

function updateAuthTabs() {
  const isLogin = authTab === "login";
  document.getElementById("auth-login-form").hidden = !isLogin;
  document.getElementById("auth-register-form").hidden = isLogin;
  const loginTab = document.getElementById("auth-tab-login");
  const registerTab = document.getElementById("auth-tab-register");
  const title = document.getElementById("auth-modal-title");

  loginTab.style.color = isLogin ? "#8C5F3B" : "#94a3b8";
  loginTab.style.borderBottomColor = isLogin ? "#8C5F3B" : "transparent";
  registerTab.style.color = isLogin ? "#94a3b8" : "#8C5F3B";
  registerTab.style.borderBottomColor = isLogin ? "transparent" : "#8C5F3B";
  title.textContent = isLogin ? "Đăng nhập để tiếp tục" : "Tạo tài khoản PND";
}

// Xử lý form Login
document
  .getElementById("auth-login-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById("auth-login-submit");
    const email =
      document.getElementById("auth-login-email")?.value.trim() || "";
    const password =
      document.getElementById("auth-login-password")?.value || "";

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = "ĐANG ĐĂNG NHẬP…";
      localStorage.removeItem("pnd_demo_mode");

      const cred = await signInWithEmailAndPassword(auth, email, password);
      if (!cred.user.emailVerified) {
        try {
          await sendEmailVerification(cred.user);
        } catch (e) {
          console.warn("Chưa gửi lại được email xác minh:", e.message);
        }
        window.dongAuthModal();
        await Swal.fire({
          icon: "warning",
          title: "Email chưa được xác minh",
          text: "PND đã gửi lại liên kết xác minh. Hãy kiểm tra hộp thư rồi bấm Tải lại trong mục Tài khoản.",
          confirmButtonColor: "#8C5F3B",
        });
        window.navigateTo?.("account");
        return;
      }
      const redirect = redirectAfterAuth;
      window.dongAuthModal();
      if (redirect) window.navigateTo?.(redirect);
    } catch (err) {
      await Swal.fire({
        icon: "error",
        title: "Đăng nhập chưa thành công",
        text: getAuthErrorMessage(err),
        confirmButtonColor: "#8C5F3B",
      });
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "ĐĂNG NHẬP";
    }
  });

// Xử lý form Đăng ký
document
  .getElementById("auth-register-form")
  ?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const submitBtn = document.getElementById("auth-register-submit");
    const name =
      document
        .getElementById("auth-register-name")
        ?.value.trim()
        .replace(/\s+/g, " ") || "";
    const email =
      document.getElementById("auth-register-email")?.value.trim() || "";
    const password =
      document.getElementById("auth-register-password")?.value || "";
    const confirm =
      document.getElementById("auth-register-confirm")?.value || "";

    if (name.length < 2) {
      return Swal.fire({
        icon: "warning",
        title: "Thiếu tên hiển thị",
        text: "Tên cần ít nhất 2 ký tự.",
        confirmButtonColor: "#8C5F3B",
      });
    }
    if (password.length < 8) {
      return Swal.fire({
        icon: "warning",
        title: "Mật khẩu chưa đủ mạnh",
        text: "Mật khẩu cần ít nhất 8 ký tự.",
        confirmButtonColor: "#8C5F3B",
      });
    }
    if (password !== confirm) {
      return Swal.fire({
        icon: "warning",
        title: "Mật khẩu chưa khớp",
        text: "Hãy nhập lại hai mật khẩu giống nhau.",
        confirmButtonColor: "#8C5F3B",
      });
    }

    try {
      submitBtn.disabled = true;
      submitBtn.textContent = "ĐANG TẠO TÀI KHOẢN…";
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName: name });
      try {
        await sendEmailVerification(cred.user);
      } catch (e) {
        console.warn("Chưa gửi được email xác minh:", e.message);
      }
      window.dongAuthModal();
      await Swal.fire({
        icon: "success",
        title: "Hãy xác minh email",
        text: "PND đã gửi liên kết xác minh. Bạn cần xác minh email trước khi xem đề hoặc nộp bài.",
        confirmButtonColor: "#8C5F3B",
      });
      window.navigateTo?.("account");
    } catch (err) {
      await Swal.fire({
        icon: "error",
        title: "Không thể tạo tài khoản",
        text: getAuthErrorMessage(err),
        confirmButtonColor: "#8C5F3B",
      });
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "TẠO TÀI KHOẢN";
    }
  });

// Quên mật khẩu
document.getElementById("auth-forgot")?.addEventListener("click", async () => {
  const email = document.getElementById("auth-login-email")?.value.trim() || "";
  if (!email) {
    return Swal.fire({
      icon: "info",
      title: "Nhập email trước",
      text: "Hãy nhập email để nhận liên kết đặt lại mật khẩu.",
      confirmButtonColor: "#8C5F3B",
    });
  }
  try {
    await sendPasswordResetEmail(auth, email);
    await Swal.fire({
      icon: "success",
      title: "Đã gửi hướng dẫn",
      text: "Hãy kiểm tra hộp thư và cả thư mục Spam.",
      confirmButtonColor: "#8C5F3B",
    });
  } catch (err) {
    await Swal.fire({
      icon: "error",
      title: "Chưa gửi được",
      text: getAuthErrorMessage(err),
      confirmButtonColor: "#8C5F3B",
    });
  }
});

// Tự động mở modal nếu URL có ?auth=login hoặc ?auth=register
const urlParam = new URLSearchParams(window.location.search).get("auth");
if (urlParam === "login" || urlParam === "register") {
  window.history.replaceState(
    {},
    "",
    `${window.location.pathname}${window.location.hash}`,
  );
  setTimeout(() => {
    if (!auth.currentUser) window.moAuthModal(urlParam);
  }, 0);
}

// ============================================================
// 6. QUẢN LÝ ĐỀ THI (LOAD TỪ FIRESTORE + LOCAL)
// ============================================================

/** Tải danh sách Kho đề (có phân trang, cache) */
window.taiDanhSachDeThi = async function ({ append = false } = {}) {
  const grid = document.getElementById("exam-grid");
  if (!grid) return;

  if (!append) {
    grid.innerHTML =
      '<p class="text-slate-500 italic col-span-full text-center py-4">Đang tải kho đề...</p>';
  }
  const loadMoreBtn = document.getElementById("exam-load-more");
  if (loadMoreBtn) {
    loadMoreBtn.disabled = append;
    loadMoreBtn.innerHTML = append
      ? '<i class="fas fa-spinner fa-spin mr-2"></i>ĐANG TẢI THÊM…'
      : '<i class="fas fa-chevron-down mr-2"></i>XEM THÊM ĐỀ';
  }

  window.khoDeNative = {};
  const examList = [];

  // 1. Đọc đề local (từ localStorage)
  try {
    const localExams = JSON.parse(
      localStorage.getItem("pnd_local_exams") || "[]",
    );
    if (Array.isArray(localExams)) {
      localExams.forEach((exam) => {
        if (!Array.isArray(exam.questions)) return;
        const key = `local:${exam.id}`;
        const fullName = `${exam.title || ""} ${exam.subject || ""}`;
        const subjectCat = detectSubjectCategory(
          exam.subjectCategory || exam.phanLoaiMon || exam.subject,
          fullName,
        );
        const format = detectExamFormat(
          exam.examFormat || exam.kyThi || exam.examType,
          fullName,
        );
        window.khoDeNative[key] = {
          ...exam,
          subjectCategory: subjectCat,
          examFormat: format,
          source: "local",
        };
        examList.push({
          key,
          title: exam.title,
          subject: exam.subject,
          subjectCategory: subjectCat,
          examFormat: format,
          code: exam.code,
          duration: exam.durationMinutes,
          questionCount: exam.questions.length,
          source: "local",
          createdAt: toMillis(exam.updatedAt || exam.createdAt),
        });
      });
    }
  } catch (e) {
    console.warn("Không đọc được kho đề local:", e);
  }

  // 2. Đọc đề từ Firestore (nếu đã đăng nhập)
  if (auth.currentUser) {
    try {
      const snapshot = await loadKhoDe({ append });
      snapshot.forEach((doc) => {
        const data = doc.data();
        // Chỉ xử lý đề có nội dung JSON hoặc đã chuyển đổi
        if (
          Array.isArray(data.questions) ||
          data.sourceFormat === "native-json" ||
          data.contentRef ||
          data.schemaVersion >= 5
        ) {
          const key = `firestore:${doc.id}`;
          const attemptPolicy =
            data.attemptPolicy || (data.hanChot ? "single" : "multiple");
          const fullName = `${data.title || data.tenDeThi || ""} ${data.subject || data.monHoc || ""}`;
          const subjectCat = detectSubjectCategory(
            data.subjectCategory ||
              data.phanLoaiMon ||
              data.subject ||
              data.monHoc,
            fullName,
          );
          const format = detectExamFormat(
            data.examFormat || data.kyThi || data.examType,
            fullName,
          );
          window.khoDeNative[key] = {
            id: doc.id,
            title: data.title || data.tenDeThi,
            subject: data.subject || data.monHoc || "Tổng hợp",
            subjectCategory: subjectCat,
            examFormat: format,
            code: data.code || data.maDe || "",
            durationMinutes: data.durationMinutes || data.thoiGianLamBai || 90,
            questions: Array.isArray(data.questions) ? data.questions : null,
            scoring: data.scoring || {},
            questionCount:
              Number(data.questionCount) || data.questions?.length || 0,
            questionTypeCounts: data.questionTypeCounts || {},
            maxScore: 10,
            contentRef: data.contentRef || doc.id,
            source: "firestore",
            deadline: data.hanChot || "",
            attemptPolicy: attemptPolicy,
          };
          examList.push({
            key: key,
            title: data.title || data.tenDeThi,
            subject: data.subject || data.monHoc,
            subjectCategory: subjectCat,
            examFormat: format,
            code: data.code || data.maDe,
            duration: data.durationMinutes || data.thoiGianLamBai,
            questionCount:
              Number(data.questionCount) || data.questions?.length || 0,
            source: "firestore",
            createdAt: toMillis(data.capNhat || data.ngayTao),
            attemptPolicy: attemptPolicy,
            submission: window.ketQuaTheoDe[doc.id] || null,
            session: window.phienTheoDe[doc.id] || null,
          });
        } else {
          // Đề cũ (chỉ có PDF + đáp án)
          const answers = data.dapAn || [];
          const encoded = encodeURIComponent(JSON.stringify(answers));
          const docId = escapeHtml(doc.id);
          const link = String(data.linkPDF || "").replace(/'/g, "%27");
          examList.push({
            title: data.tenDeThi,
            subject: "Định dạng cũ",
            subjectCategory: "other",
            examFormat: detectExamFormat(
              data.examFormat || data.kyThi,
              data.tenDeThi || "",
            ),
            duration: data.thoiGianLamBai || 60,
            questionCount: answers.length,
            source: "legacy",
            createdAt: toMillis(data.capNhat || data.ngayTao),
            legacyClick: `moDeThi('${docId}', '${link}', '${encoded}', ${data.thoiGianLamBai || 60})`,
          });
        }
      });
    } catch (e) {
      console.error("Không tải được Firestore:", e);
    }
  }

  window.danhSachTheDeThi = examList;
  renderExamGrid(); // Hàm hiển thị danh sách, lọc, sắp xếp (xem bên dưới)

  // Ẩn nút "Xem thêm" nếu không còn dữ liệu
  if (loadMoreBtn) {
    const hasMore = Boolean(auth.currentUser && cacheStore.khoDe.hasMore);
    loadMoreBtn.classList.toggle("hidden", !hasMore);
    loadMoreBtn.disabled = false;
    loadMoreBtn.innerHTML =
      '<i class="fas fa-chevron-down mr-2"></i>XEM THÊM ĐỀ';
  }
};

/** Hàm tải dữ liệu Kho đề từ Firestore với cache và phân trang */
async function loadKhoDe({ force = false, append = false, all = false } = {}) {
  const cache = cacheStore.khoDe;

  if (force && !append) {
    cache.snapshot = null;
    cache.loadedAt = 0;
    cache.promise = null;
    cache.cursor = null;
    cache.hasMore = true;
    cache.records = [];
  }
  if (!append && !force && isCacheValid(cache, 60000)) {
    if (all && cache.hasMore) return loadKhoDe({ append: true, all: true });
    return cache.snapshot;
  }
  if (append && !cache.hasMore) return cache.snapshot;
  if (cache.promise) return cache.promise;

  const q =
    append && cache.cursor
      ? query(
          collection(db, "KhoDeThi"),
          where("publicMetadata", "==", true),
          orderBy(documentId()),
          startAfter(cache.cursor),
          limit(24),
        )
      : query(
          collection(db, "KhoDeThi"),
          where("publicMetadata", "==", true),
          orderBy(documentId()),
          limit(24),
        );

  cache.promise = withRetry(
    () => getDocs(q),
    append ? "Tải thêm Kho đề" : "Tải Kho đề",
  )
    .then((snap) => {
      const results = [];
      snap.forEach((d) => results.push({ id: d.id, data: d.data() }));
      cache.records = append ? [...cache.records, ...results] : results;
      cache.cursor = snap.docs?.[snap.docs.length - 1] || cache.cursor;
      cache.hasMore = snap.size === 24;
      cache.snapshot = makeFakeSnapshot(cache.records);
      cache.loadedAt = Date.now();

      // Lưu metadata xuống localStorage để dùng offline
      try {
        const items = [];
        cache.snapshot.forEach((doc) => {
          const data = doc.data();
          const meta = { ...data };
          if (Array.isArray(data.questions)) {
            meta.questionCount =
              Number(data.questionCount) || data.questions.length;
            meta.questionTypeCounts = data.questions.reduce((acc, q) => {
              const type = String(q.type || "TN").toUpperCase();
              acc[type] = (acc[type] || 0) + 1;
              return acc;
            }, {});
            meta.maxScore = 10;
            meta.sourceFormat = "native-json";
            meta.contentRef = doc.id;
            // Cache nội dung câu hỏi riêng
            cacheExamContent(doc.id, {
              questions: data.questions,
              scoring: data.scoring || {},
            });
            delete meta.questions;
            delete meta.scoring;
          }
          items.push({ id: doc.id, data: meta });
        });
        localStorage.setItem(
          METADATA_KEY,
          JSON.stringify({ savedAt: Date.now(), items }),
        );
      } catch (e) {
        console.warn("Không lưu được metadata local:", e.message);
      }

      return cache.snapshot;
    })
    .catch((err) => {
      // Fallback: đọc từ cache local nếu có
      if (append && cache.snapshot) {
        cache.hasMore = false;
        return cache.snapshot;
      }
      const local = loadLocalMetadata();
      if (!local) throw err;
      console.warn("Đang dùng metadata Kho đề đã cache vì mất kết nối.");
      cache.snapshot = local;
      cache.records =
        local.docs?.map((d) => ({ id: d.id, data: d.data() })) || [];
      cache.loadedAt = Date.now();
      cache.cursor = null;
      cache.hasMore = false;
      return local;
    })
    .finally(() => {
      cache.promise = null;
    });

  const result = await cache.promise;
  if (all && cache.hasMore) return loadKhoDe({ append: true, all: true });
  return result;
}

/** Đọc metadata từ localStorage */
function loadLocalMetadata() {
  try {
    const raw = JSON.parse(localStorage.getItem(METADATA_KEY) || "null");
    if (raw && Array.isArray(raw.items) && raw.items.length) {
      return makeFakeSnapshot(raw.items, true);
    }
    return null;
  } catch {
    return null;
  }
}

// Hàm phát hiện môn học
function detectSubjectCategory(subject, fullName = "") {
  const normalized = removeAccents(subject || "").replace(/[\s_-]+/g, "");
  if (["math", "toan", "toanhoc"].includes(normalized)) return "math";
  if (["physics", "ly", "vatly", "vatli"].includes(normalized))
    return "physics";
  if (["chemistry", "hoa", "hoahoc"].includes(normalized)) return "chemistry";
  if (["english", "anh", "tienganh"].includes(normalized)) return "english";

  const combined = removeAccents(`${subject} ${fullName}`);
  if (/\b(toan|math)\b/.test(combined)) return "math";
  if (/\b(vat ly|vat li|physics|mon ly|mon li)\b/.test(combined))
    return "physics";
  if (/\b(hoa hoc|chemistry|mon hoa)\b/.test(combined)) return "chemistry";
  if (/\b(tieng anh|english|mon anh)\b/.test(combined)) return "english";
  return "other";
}

function detectExamFormat(format, fullName = "") {
  const combined = removeAccents(`${format} ${fullName}`).replace(
    /[_-]+/g,
    " ",
  );
  if (/\bhsa\b/.test(combined)) return "hsa";
  if (/\btsa\b/.test(combined)) return "tsa";
  if (/\bv\s*act\b|\bvact\b/.test(combined)) return "vact";
  return "none";
}

function removeAccents(str) {
  return String(str)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();
}

/** Chuyển đổi timestamp Firestore hoặc Date thành số milliseconds */
function toMillis(value) {
  if (value?.toMillis) return value.toMillis();
  if (value?.seconds) return value.seconds * 1000;
  const num =
    typeof value === "number" ? value : new Date(value || 0).getTime();
  return Number.isFinite(num) ? num : 0;
}

// ============================================================
// 7. HIỂN THỊ DANH SÁCH ĐỀ (FILTER, SORT, RENDER)
// ============================================================

/** Hiển thị danh sách đề lên lưới */
function renderExamGrid() {
  const grid = document.getElementById("exam-grid");
  if (!grid) return;

  const filter = window.boLocKhoDe || "all";
  const search = removeAccents(
    document.getElementById("exam-search-input")?.value || "",
  ).trim();
  const sort = document.getElementById("exam-sort-select")?.value || "newest";

  let exams = (window.danhSachTheDeThi || []).filter((exam) => {
    const matchFilter =
      filter === "all" ||
      (filter.startsWith("subject:") &&
        exam.subjectCategory === filter.split(":")[1]) ||
      (filter.startsWith("format:") &&
        exam.examFormat === filter.split(":")[1]);
    const matchSearch =
      !search ||
      removeAccents(
        `${exam.title} ${exam.subject} ${exam.code} ${subjectLabel(exam.subjectCategory) || ""} ${formatLabel(exam.examFormat) || ""}`,
      ).includes(search);
    return matchFilter && matchSearch;
  });

  // Sắp xếp
  exams.sort((a, b) => {
    if (sort === "title")
      return String(a.title || "").localeCompare(String(b.title || ""), "vi");
    if (sort === "duration")
      return (Number(a.duration) || 90) - (Number(b.duration) || 90);
    if (sort === "questions")
      return (Number(a.questionCount) || 0) - (Number(b.questionCount) || 0);
    return (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0); // newest
  });

  if (exams.length) {
    grid.innerHTML = exams.map((exam) => renderExamCard(exam)).join("");
  } else {
    const empty = !(window.danhSachTheDeThi || []).length;
    grid.innerHTML = empty
      ? `<div class="col-span-full text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
          <p class="font-bold text-slate-600">Kho đề đang trống</p>
          <p class="text-xs text-slate-400 mt-2">Mở Quản lý đề để chọn file JSON và lưu đề đầu tiên.</p>
          <a href="admin.html" class="inline-block mt-4 px-5 py-2 bg-[#8C5F3B] text-white rounded-xl text-xs font-bold">THÊM ĐỀ NGAY</a>
        </div>`
      : `<div class="col-span-full text-center py-12 bg-white rounded-3xl border border-dashed border-slate-200">
          <p class="font-bold text-slate-600">Không tìm thấy đề phù hợp</p>
          <p class="text-xs text-slate-400 mt-2">Hãy thử đổi danh mục hoặc từ khóa tìm kiếm.</p>
        </div>`;
  }
}

/** Tạo HTML cho 1 thẻ đề */
function renderExamCard(exam) {
  const isSingle =
    exam.source === "firestore" &&
    exam.attemptPolicy === "single" &&
    Boolean(exam.submission);
  const clickHandler = isSingle
    ? `xemKetQuaCaNhan('${exam.submission.docId}')`
    : exam.legacyClick || `moDeThiNativeTheoID('${exam.key}')`;
  const sourceLabel =
    exam.source === "local"
      ? "LOCAL"
      : exam.source === "firestore"
        ? "JSON"
        : "PDF CŨ";
  const status = exam.submission?.data?.congBoDapAn
    ? "ĐÁP ÁN ĐÃ MỞ"
    : exam.submission?.data?.trangThaiCham === "da_cham"
      ? "ĐÃ CHẤM"
      : exam.submission
        ? "ĐÃ NỘP"
        : exam.session
          ? "ĐANG LÀM"
          : "";
  const format = formatLabel(exam.examFormat);

  return `
    <button type="button" onclick="${clickHandler}" class="text-left group flex flex-col bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border ${isSingle ? "border-emerald-200" : "border-slate-100"}">
      <div class="h-32 relative flex items-center justify-center overflow-hidden border-b border-slate-100 bg-gradient-to-br from-amber-50 to-orange-100">
        <h3 class="text-4xl font-black text-amber-900/10 uppercase tracking-widest absolute">${escapeHtml(exam.code || exam.subject || "PND")}</h3>
        <div class="absolute top-3 left-3 bg-[#8C5F3B] text-white px-2.5 py-1 rounded-full text-[9px] font-black">${sourceLabel}</div>
        ${format ? `<div class="absolute top-12 left-3 bg-slate-900/80 text-white px-2.5 py-1 rounded-full text-[9px] font-black">${format}</div>` : ""}
        ${status ? `<div class="absolute bottom-3 left-3 bg-emerald-600 text-white px-2.5 py-1 rounded-full text-[9px] font-black">${status}</div>` : ""}
        <div class="absolute top-3 right-3 bg-white/80 backdrop-blur-sm px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-sm border border-white">
          <i class="fas fa-clock text-[#8C5F3B] text-[10px]"></i>
          <span class="text-xs font-bold text-slate-700">${Number(exam.duration) || 90}p</span>
        </div>
      </div>
      <div class="p-6 flex flex-col flex-grow w-full">
        <h3 class="text-lg font-bold text-slate-800 mb-2 group-hover:text-[#8C5F3B] transition-colors line-clamp-2">${escapeHtml(exam.title || "Đề chưa đặt tên")}</h3>
        <p class="text-slate-500 text-xs leading-relaxed mb-5 flex-grow">${subjectLabel(exam.subjectCategory) || exam.subject || "Khác"}${format ? ` · ${format}` : ""} · ${Number(exam.questionCount) || 0} câu hỏi.</p>
        <div class="flex items-center justify-between pt-4 border-t border-slate-50">
          <span class="px-3 py-1 bg-amber-50 text-[#8C5F3B] text-[10px] font-black uppercase rounded-md">${sourceLabel}</span>
          <span class="text-xs font-bold ${isSingle ? "text-emerald-600" : "text-slate-400 group-hover:text-[#8C5F3B]"}">${isSingle ? "XEM KẾT QUẢ →" : exam.session ? "TIẾP TỤC →" : exam.submission ? "LÀM LẠI →" : "LÀM BÀI →"}</span>
        </div>
      </div>
      <div class="h-1 w-full bg-slate-100 relative overflow-hidden"><div class="absolute inset-0 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-500 bg-[#8C5F3B]"></div></div>
    </button>
  `;
}

function subjectLabel(cat) {
  const map = {
    math: "Toán",
    physics: "Vật lý",
    chemistry: "Hóa học",
    english: "Tiếng Anh",
    other: "Khác",
  };
  return map[cat] || cat;
}

function formatLabel(fmt) {
  const map = { hsa: "HSA", tsa: "TSA", vact: "V-ACT" };
  return map[fmt] || "";
}

// ============================================================
// 8. KẾT QUẢ & PHIÊN THI CÁ NHÂN
// ============================================================

/** Tải kết quả thi của người dùng từ Firestore (có cache) */
async function loadKetQua({ force = false } = {}) {
  if (!auth.currentUser) return null;
  resetUserCache(auth.currentUser.uid);
  const cache = cacheStore.ketQua;

  if (!force && isCacheValid(cache, 30000)) return cache.snapshot;
  if (cache.promise) return cache.promise;

  const uid = auth.currentUser.uid;
  const q = query(
    collection(db, "KetQuaThi"),
    where("email", "==", auth.currentUser.email),
  );
  cache.promise = withRetry(() => getDocs(q), "Tải kết quả cá nhân")
    .then((snap) => {
      if (auth.currentUser?.uid !== uid)
        throw new Error("Phiên tài khoản đã thay đổi.");
      cache.snapshot = snap;
      cache.loadedAt = Date.now();
      return snap;
    })
    .finally(() => {
      cache.promise = null;
    });

  return cache.promise;
}

/** Tải phiên thi (đang làm) của người dùng */
async function loadPhien({ force = false } = {}) {
  if (!auth.currentUser) return null;
  resetUserCache(auth.currentUser.uid);
  const cache = cacheStore.phien;

  if (!force && isCacheValid(cache, 30000)) return cache.snapshot;
  if (cache.promise) return cache.promise;

  const uid = auth.currentUser.uid;
  const q = query(
    collection(db, "PhienThi"),
    where("email", "==", auth.currentUser.email),
  );
  cache.promise = withRetry(() => getDocs(q), "Tải phiên thi")
    .then((snap) => {
      if (auth.currentUser?.uid !== uid)
        throw new Error("Phiên tài khoản đã thay đổi.");
      cache.snapshot = snap;
      cache.loadedAt = Date.now();
      return snap;
    })
    .finally(() => {
      cache.promise = null;
    });

  return cache.promise;
}

/** Cập nhật biến toàn cục ketQuaTheoDe và phienTheoDe */
window.taiDuLieuDashboard = async function () {
  if (!auth.currentUser) return;

  try {
    const [ketQuaSnap, phienSnap] = await Promise.all([
      loadKetQua(),
      loadPhien(),
    ]);
    const ketQuaMap = {};
    ketQuaSnap.forEach((doc) => {
      const data = doc.data();
      if (!data.deThiID) return;
      const existing = ketQuaMap[data.deThiID];
      const time = data.thoiGianNop?.toMillis ? data.thoiGianNop.toMillis() : 0;
      const prevTime = existing?.data?.thoiGianNop?.toMillis
        ? existing.data.thoiGianNop.toMillis()
        : -1;
      if (!existing || time >= prevTime) {
        ketQuaMap[data.deThiID] = { docId: doc.id, data };
      }
    });
    window.ketQuaTheoDe = ketQuaMap;

    const phienMap = {};
    phienSnap.forEach((doc) => {
      const data = doc.data();
      if (data.deThiID && data.status === "dang_lam") {
        phienMap[data.deThiID] = { docId: doc.id, data };
      }
    });
    window.phienTheoDe = phienMap;
  } catch (e) {
    console.warn("Không đọc được trạng thái bài đã nộp:", e);
  }
};

// ============================================================
// 9. QUẢN LÝ PHIÊN THI, CHỐNG GIAN LẬN, NHÁP BÀI
// ============================================================

/** Xác định đề có hạn chế một lượt không */
function isSingleAttempt(exam) {
  return exam.attemptPolicy
    ? exam.attemptPolicy === "single"
    : Boolean(exam.deadline || exam.hanChot);
}

/** Tạo key cho Phiên thi (dùng cho single attempt) */
function getSessionKey(examId) {
  return auth.currentUser ? `${examId}__${auth.currentUser.uid}` : "";
}

/** Tạo hoặc lấy phiên thi hiện tại (Firestore) */
async function getOrCreateSession(exam) {
  if (
    !auth.currentUser ||
    exam.source !== "firestore" ||
    !isSingleAttempt(exam)
  )
    return null;

  const sessionId = getSessionKey(exam.id);
  const ref = doc(db, "PhienThi", sessionId);
  let snap = await getDoc(ref);

  if (!snap.exists()) {
    await setDoc(ref, {
      deThiID: exam.id,
      uid: auth.currentUser.uid,
      email: auth.currentUser.email,
      tenDeThi: exam.title || "Đề thi",
      durationSeconds: Math.max(
        60,
        Math.round(60 * (Number(exam.durationMinutes) || 90)),
      ),
      startedAt: serverTimestamp(),
      lastSeenAt: serverTimestamp(),
      violationCount: 0,
      status: "dang_lam",
      schemaVersion: 1,
    });
    snap = await getDoc(ref);
  }

  if (!snap.exists())
    throw new Error("Không thể tạo phiên thi bằng giờ máy chủ.");
  if (snap.data().status === "da_nop") throw new Error("SESSION_SUBMITTED");

  return { id: sessionId, ref, snapshot: snap };
}

/** Tạo khoá tab (anti-cheat) để tránh mở nhiều tab */
function lockExamTab(examId) {
  const key = `pnd_exam_tab_lock_${examId}`;
  const tabId = (() => {
    let id = sessionStorage.getItem("pnd_exam_tab_id");
    if (!id) {
      id = `tab-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      sessionStorage.setItem("pnd_exam_tab_id", id);
    }
    return id;
  })();

  // Kiểm tra tab khác đang giữ khoá
  const now = Date.now();
  try {
    const existing = JSON.parse(localStorage.getItem(key) || "{}");
    if (
      existing.tabId &&
      existing.tabId !== tabId &&
      now - Number(existing.heartbeat || 0) < 12000
    ) {
      throw new Error("MULTI_TAB");
    }
  } catch (e) {
    if (e.message === "MULTI_TAB") throw e;
  }

  const heartbeat = () => {
    localStorage.setItem(key, JSON.stringify({ tabId, heartbeat: Date.now() }));
  };
  heartbeat();

  // Dọn dẹp interval cũ
  if (window.khoaTabThiHienTai?.interval)
    clearInterval(window.khoaTabThiHienTai.interval);
  window.khoaTabThiHienTai = {
    key,
    tabId,
    interval: setInterval(heartbeat, 3000),
  };
}

// ============================================================
// 10. ANTI-CHEAT
// ============================================================

window.canhCaoGianLan = 0;
window.antiCheatDangBat = false;

window.batAntiCheat = function () {
  window.tatAntiCheat();
  window.antiCheatDangBat = true;
  window.canhCaoGianLan = Number(window.phienThiHienTai?.violationCount) || 0;

  document.body.style.userSelect = "none";
  document.addEventListener("visibilitychange", window.kiemTraChuyenTab);
  window.addEventListener("blur", window.kiemTraMatFocus);
  document.addEventListener("contextmenu", window.chanChuotPhai);
  document.addEventListener("keydown", window.chanPhimTat);

  // Phát hiện mở DevTools bằng kích thước
  window.vongLapQuetGianLan = setInterval(() => {
    if (!window.antiCheatDangBat) return;
    const widthDiff = window.outerWidth - window.innerWidth > 160;
    const heightDiff = window.outerHeight - window.innerHeight > 160;
    if (widthDiff || heightDiff) {
      window.xuLyViPham("Phát hiện mở công cụ F12 hoặc chia nhỏ màn hình!");
    }
  }, 1000);

  console.log("🔒 Hệ thống bảo mật đã kích hoạt!");
};

window.tatAntiCheat = function () {
  window.antiCheatDangBat = false;
  document.body.style.userSelect = "auto";
  document.removeEventListener("visibilitychange", window.kiemTraChuyenTab);
  window.removeEventListener("blur", window.kiemTraMatFocus);
  document.removeEventListener("contextmenu", window.chanChuotPhai);
  document.removeEventListener("keydown", window.chanPhimTat);
  if (window.vongLapQuetGianLan) {
    clearInterval(window.vongLapQuetGianLan);
    window.vongLapQuetGianLan = null;
  }
};

window.kiemTraChuyenTab = function () {
  if (window.antiCheatDangBat && document.hidden) {
    window.xuLyViPham("Phát hiện che khuất hoặc chuyển tab trình duyệt!");
  }
};

window.kiemTraMatFocus = function () {
  setTimeout(() => {
    if (
      window.antiCheatDangBat &&
      !document.querySelector(".swal2-container") &&
      document.activeElement &&
      document.activeElement.tagName !== "IFRAME"
    ) {
      window.xuLyViPham("Phát hiện click chuột ra ngoài khu vực thi!");
    }
  }, 150);
};

window.chanChuotPhai = function (e) {
  e.preventDefault();
};

window.chanPhimTat = function (e) {
  if (
    e.key === "F12" ||
    (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "i")) ||
    (e.ctrlKey &&
      (e.key === "c" ||
        e.key === "v" ||
        e.key === "u" ||
        e.key === "C" ||
        e.key === "V" ||
        e.key === "U"))
  ) {
    e.preventDefault();
    window.xuLyViPham("Phát hiện sử dụng phím tắt bị cấm!");
  }
};

window.xuLyViPham = function (message) {
  if (!window.antiCheatDangBat) return;
  window.canhCaoGianLan++;
  window.ghiNhanViPhamPhienThi(window.canhCaoGianLan);

  if (window.canhCaoGianLan >= 3) {
    window.tatAntiCheat();
    Swal.fire({
      title: "ĐÌNH CHỈ THI!",
      text: "Bạn đã vi phạm quy chế quá 3 lần. Hệ thống đang tự động thu bài.",
      icon: "error",
      showConfirmButton: false,
      timer: 3000,
    }).then(() => {
      window.nopBai(true);
    });
  } else {
    Swal.fire({
      title: "CẢNH CÁO GIAN LẬN!",
      html: `<p class="text-slate-600">${message}</p><p class="text-red-500 font-bold mt-2">Vi phạm lần: ${window.canhCaoGianLan}/3</p>`,
      icon: "warning",
      confirmButtonColor: "#8C5F3B",
    });
  }
};

// Lưu vi phạm lên Firestore
window.ghiNhanViPhamPhienThi = function (count) {
  const session = window.phienThiHienTai;
  if (!session?.ref || session.status !== "dang_lam") return;
  const newCount = Number(count) || 0;
  window.hangDoiLuuViPham = window.hangDoiLuuViPham.then(() =>
    updateDoc(session.ref, {
      lastSeenAt: serverTimestamp(),
      violationCount: newCount,
      status: "dang_lam",
    })
      .then(() => {
        session.violationCount = newCount;
      })
      .catch((err) => console.warn("Không đồng bộ được vi phạm:", err.message)),
  );
};

// ============================================================
// 11. LÀM BÀI THI (RENDER CÂU HỎI, CHỌN ĐÁP ÁN, NỘP BÀI)
// ============================================================

window.baiLamCuaToi = {};

/** Render đề thi Native (JSON) */
window.renderDeThiNative = function (exam) {
  if (!auth.currentUser && localStorage.getItem("pnd_demo_mode") !== "1") {
    window.moAuthModal?.("login", "Bạn cần đăng nhập trước khi vào phòng thi.");
    return;
  }

  window.deThiMauHienTai = exam;
  window.baiLamCuaToi = loadDraft(exam) || {};
  localStorage.setItem("deThiDangLam_ID", exam.id || "local-json");
  localStorage.setItem(
    "deThiDangLam_BatDau",
    String(window.phienThiHienTai?.startedMillis || Date.now()),
  );

  // Chuyển sang view làm bài
  document
    .querySelectorAll(".view-section")
    .forEach((el) => el.classList.remove("active"));
  document.getElementById("view-doing-exam").classList.add("active");
  document.getElementById("exam-doing-title").innerText =
    exam.title || "Đề thi JSON";
  document.getElementById("answer-sheet-title").innerText = "BẢN ĐỒ CÂU HỎI";

  const container = document.getElementById("native-question-container");
  const answerSheet = document.getElementById("answer-sheet");
  const questions = Array.isArray(exam.questions) ? exam.questions : [];

  // Kích hoạt anti-cheat nếu là đề Firestore
  if (
    exam.source === "firestore" &&
    typeof window.batAntiCheat === "function"
  ) {
    window.batAntiCheat();
  }

  // Render từng câu hỏi
  container.innerHTML = questions
    .map((q, idx) => renderQuestion(q, idx))
    .join("");

  // Render bản đồ câu hỏi (answer sheet)
  answerSheet.innerHTML = `
    <div class="grid grid-cols-5 md:grid-cols-4 gap-2 pb-4">
      ${questions
        .map(
          (_, idx) => `
        <button type="button" onclick="cuonDenCau(${idx}); toggleAnswerSheet(false)" id="map-btn-${idx}"
          class="aspect-square min-h-[42px] rounded-xl bg-slate-100 border border-slate-200 text-sm font-bold text-slate-500 hover:border-[#8C5F3B] transition flex items-center justify-center">${idx + 1}</button>
      `,
        )
        .join("")}
    </div>
  `;

  // Cập nhật tiến độ
  const progress = document.getElementById("answer-sheet-progress");
  if (progress) progress.innerText = `0/${questions.length} câu`;
  window.toggleAnswerSheet(false);

  // Áp dụng draft nếu có
  setTimeout(() => {
    if (
      window.phienThiHienTai &&
      Object.keys(window.baiLamCuaToi || {}).length > 0
    ) {
      applyDraftToUI();
    }
    window.capNhatTienDoDeNative();
  }, 0);

  // Bắt đầu đồng hồ
  const remaining = Number.isFinite(Number(exam._remainingSeconds))
    ? Number(exam._remainingSeconds)
    : null;
  window.batDauDongHoLocal(exam.durationMinutes || 90, remaining);

  // Render công thức toán (KaTeX)
  loadKatex()
    .then(() => {
      if (typeof renderMathInElement === "function") {
        renderMathInElement(container, {
          delimiters: [
            { left: "$$", right: "$$", display: true },
            { left: "$", right: "$", display: false },
          ],
          throwOnError: false,
        });
      }
    })
    .catch((err) => console.warn("Không render được công thức:", err.message));
};

/** Hàm render một câu hỏi */
function renderQuestion(q, idx) {
  let optionsHtml = "";
  const type = q.type || "TN";

  switch (type) {
    case "TN": {
      if (q.options) {
        optionsHtml = `
          <div class="grid grid-cols-1 lg:grid-cols-2 gap-3 mt-5" id="dapan-group-${idx}">
            ${Object.entries(q.options)
              .filter(([key]) => ["A", "B", "C", "D"].includes(key))
              .map(
                ([key, text]) => `
                <button type="button" data-q-index="${idx}" data-answer="${key}" onclick="chonDapAnTrucTiep(this, ${idx}, '${key}')"
                  class="dap-an-btn min-h-[58px] p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-[#8C5F3B] cursor-pointer transition text-slate-700 font-semibold flex items-center text-left">
                  <span class="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center mr-3 shrink-0 label-abcd font-black text-[#8C5F3B]">${key}</span>
                  <span>${escapeHtml(text)}</span>
                </button>
              `,
              )
              .join("")}
          </div>
        `;
      }
      break;
    }
    case "DS": {
      if (Array.isArray(q.statements)) {
        if (!Array.isArray(window.baiLamCuaToi[idx]))
          window.baiLamCuaToi[idx] = [];
        optionsHtml = `
          <div class="mt-5 space-y-3">
            ${q.statements
              .map(
                (stmt, si) => `
              <div class="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <p class="text-sm text-slate-700 leading-relaxed"><b>${escapeHtml(stmt.id || ["a", "b", "c", "d"][si])}.</b> ${escapeHtml(stmt.text || "")}</p>
                <div id="ds-group-${idx}-${si}" class="flex gap-2 shrink-0">
                  <button type="button" data-q-index="${idx}" data-statement-index="${si}" data-answer="T" onclick="chonDapAnDungSaiNative(this, ${idx}, ${si}, 'T')"
                    class="ds-answer-btn min-w-[48px] min-h-[42px] px-3 rounded-lg border-2 border-slate-200 bg-white text-emerald-700 font-black">Đ</button>
                  <button type="button" data-q-index="${idx}" data-statement-index="${si}" data-answer="F" onclick="chonDapAnDungSaiNative(this, ${idx}, ${si}, 'F')"
                    class="ds-answer-btn min-w-[48px] min-h-[42px] px-3 rounded-lg border-2 border-slate-200 bg-white text-red-600 font-black">S</button>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        `;
      }
      break;
    }
    case "DN": {
      optionsHtml = `
        <div class="mt-5 w-full md:w-1/2">
          <label class="block text-[10px] font-black text-slate-400 uppercase mb-2">Kết quả của bạn</label>
          <input type="text" data-q-index="${idx}" oninput="chonDapAnDienNgan(this, ${idx})" placeholder="Nhập đáp án..."
            class="native-dn-input w-full p-4 border-2 border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:border-[#8C5F3B] outline-none transition-colors">
        </div>
      `;
      break;
    }
    case "TL": {
      optionsHtml = `
        <div class="mt-5">
          <label class="block text-[10px] font-black text-slate-400 uppercase mb-2">Bài làm tự luận</label>
          <textarea data-q-index="${idx}" oninput="chonDapAnTuLuanNative(this, ${idx})" rows="6" placeholder="Nhập lời giải hoặc ghi chú bài làm tại đây..."
            class="native-tl-input w-full p-4 border-2 border-slate-200 rounded-xl text-sm text-slate-700 focus:border-[#8C5F3B] outline-none transition-colors resize-y"></textarea>
          <p class="text-[10px] text-amber-700 mt-2"><i class="fas fa-user-check mr-1"></i>Câu này cần giáo viên chấm.</p>
        </div>
      `;
      break;
    }
  }

  // Hình ảnh
  const img = String(q.image || "").trim();
  const imageHtml = /^(https?:\/\/|assets\/|data:image\/)/i.test(img)
    ? `<figure class="mt-5"><img loading="lazy" decoding="async" class="native-question-image" src="${escapeHtml(img)}" alt="${escapeHtml(q.imageAlt || "Hình minh họa câu hỏi")}"><figcaption class="text-center text-[10px] text-slate-400 mt-2">Hình minh họa câu hỏi</figcaption></figure>`
    : "";

  const typeLabel =
    {
      TN: "Chọn 1 đáp án",
      DS: "Đúng / Sai",
      DN: "Trả lời ngắn",
      TL: "Tự luận",
    }[type] || "Câu hỏi";

  return `
    <article id="cau-hoi-${idx}" class="native-question-card mb-9 pb-8 border-b border-slate-100 last:border-0">
      <div class="flex items-start gap-3">
        <div class="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 font-black flex items-center justify-center shrink-0 shadow-sm">${idx + 1}</div>
        <div class="flex-1 min-w-0">
          <div class="flex flex-wrap items-center gap-2 mb-2">
            <span class="text-[10px] font-black text-[#8C5F3B] uppercase">${typeLabel}</span>
            <span class="text-[9px] font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded-full">${escapeHtml(q.topic || "Tổng hợp")}</span>
          </div>
          <p class="text-base md:text-lg text-slate-800 font-semibold leading-relaxed">${escapeHtml(q.prompt || "")}</p>
          ${imageHtml}
          ${optionsHtml}
        </div>
      </div>
    </article>
  `;
}

// Các hàm chọn đáp án
window.chonDapAnTrucTiep = function (btn, index, answer) {
  const original = window.baiLamCuaToi;
  original[index] = answer;

  // Cập nhật UI
  const group = document.getElementById(`dapan-group-${index}`);
  if (group) {
    group.querySelectorAll(".dap-an-btn").forEach((b) => {
      b.classList.remove("bg-amber-50", "border-[#8C5F3B]");
      b.classList.add("bg-slate-50", "border-slate-100");
      const label = b.querySelector(".label-abcd");
      if (label) {
        label.classList.remove(
          "bg-[#8C5F3B]",
          "text-white",
          "border-[#8C5F3B]",
        );
        label.classList.add("bg-white", "text-[#8C5F3B]", "border-slate-200");
      }
    });
    btn.classList.remove("bg-slate-50", "border-slate-100");
    btn.classList.add("bg-amber-50", "border-[#8C5F3B]");
    const label = btn.querySelector(".label-abcd");
    if (label) {
      label.classList.remove("bg-white", "text-[#8C5F3B]", "border-slate-200");
      label.classList.add("bg-[#8C5F3B]", "text-white", "border-[#8C5F3B]");
    }
  }
  updateProgress(index, true);
};

window.chonDapAnDienNgan = function (input, index) {
  const value = input.value.trim();
  window.baiLamCuaToi[index] = value;
  updateProgress(index, value !== "");
};

window.chonDapAnDungSaiNative = function (btn, idx, stmtIdx, answer) {
  if (!Array.isArray(window.baiLamCuaToi[idx])) window.baiLamCuaToi[idx] = [];
  window.baiLamCuaToi[idx][stmtIdx] = answer;

  const group = document.getElementById(`ds-group-${idx}-${stmtIdx}`);
  if (group) {
    group.querySelectorAll(".ds-answer-btn").forEach((b) => {
      b.classList.remove(
        "border-emerald-500",
        "bg-emerald-50",
        "border-red-500",
        "bg-red-50",
      );
    });
    btn.classList.add(
      answer === "T" ? "border-emerald-500" : "border-red-500",
      answer === "T" ? "bg-emerald-50" : "bg-red-50",
    );
  }

  const allAnswered = window.baiLamCuaToi[idx]?.filter(Boolean).length === 4;
  updateProgress(idx, allAnswered);
};

window.chonDapAnTuLuanNative = function (textarea, index) {
  window.baiLamCuaToi[index] = textarea.value;
  updateProgress(index, textarea.value.trim().length > 0);
};

function updateProgress(index, answered) {
  const btn = document.getElementById(`map-btn-${index}`);
  if (btn) {
    if (answered) {
      btn.classList.add("bg-[#8C5F3B]", "text-white", "border-[#8C5F3B]");
      btn.classList.remove(
        "bg-slate-100",
        "text-slate-500",
        "border-slate-200",
      );
    } else {
      btn.classList.remove("bg-[#8C5F3B]", "text-white", "border-[#8C5F3B]");
      btn.classList.add("bg-slate-100", "text-slate-500", "border-slate-200");
    }
  }
  window.capNhatTienDoDeNative();
  // Tự động lưu draft
  window.luuBanNhapBaiThi();
}

window.capNhatTienDoDeNative = function () {
  const exam = window.deThiMauHienTai;
  if (!exam) return;
  const answers = window.baiLamCuaToi || {};
  const total = exam.questions.length;
  const answered = Object.values(answers).filter((v) =>
    Array.isArray(v)
      ? v.filter(Boolean).length === 4
      : String(v ?? "").trim() !== "",
  ).length;
  const progress = document.getElementById("answer-sheet-progress");
  if (progress) progress.innerText = `${answered}/${total} câu`;
  window.luuBanNhapBaiThi();
};

/** Lưu bản nháp bài thi */
window.luuBanNhapBaiThi = function () {
  const exam = window.deThiMauHienTai;
  if (!exam || exam.source !== "firestore" || !window.phienThiHienTai) return;
  try {
    const key = getDraftKey(exam.id);
    localStorage.setItem(
      key,
      JSON.stringify({
        examId: exam.id,
        uid: auth.currentUser?.uid || "",
        sessionStartedMillis: window.phienThiHienTai?.startedMillis || 0,
        violationCount:
          Number(window.canhCaoGianLan) ||
          Number(window.phienThiHienTai?.violationCount) ||
          0,
        answers: window.baiLamCuaToi || {},
        savedAt: Date.now(),
        schemaVersion: 1,
      }),
    );
  } catch (e) {
    console.warn("Không lưu được bản nháp:", e);
  }
};

function getDraftKey(examId) {
  return `pnd_exam_draft_${auth.currentUser?.uid || "local"}_${examId}`;
}

function loadDraft(exam) {
  if (!exam?.id || !auth.currentUser) return {};
  try {
    const raw = localStorage.getItem(getDraftKey(exam.id));
    if (!raw) return {};
    const data = JSON.parse(raw);
    if (data.examId !== exam.id || data.uid !== auth.currentUser.uid) return {};
    // Kiểm tra phiên
    if (
      window.phienThiHienTai &&
      Number(data.sessionStartedMillis) !==
        Number(window.phienThiHienTai.startedMillis)
    ) {
      localStorage.removeItem(getDraftKey(exam.id));
      return {};
    }
    if (window.phienThiHienTai) {
      const serverViolations =
        Number(window.phienThiHienTai.violationCount) || 0;
      const draftViolations = Number(data.violationCount) || 0;
      const maxViolations = Math.max(serverViolations, draftViolations);
      window.phienThiHienTai.violationCount = maxViolations;
      window.canhCaoGianLan = maxViolations;
      if (maxViolations > serverViolations) {
        window.ghiNhanViPhamPhienThi(maxViolations);
      }
    }
    return data.answers || {};
  } catch {
    return {};
  }
}

function applyDraftToUI() {
  const exam = window.deThiMauHienTai;
  if (!exam) return;
  exam.questions.forEach((q, idx) => {
    const answer = window.baiLamCuaToi?.[idx];
    if (answer == null) return;
    if (q.type === "TN") {
      const btn = document.querySelector(
        `.dap-an-btn[data-q-index="${idx}"][data-answer="${String(answer).toUpperCase()}"]`,
      );
      if (btn) window.chonDapAnTrucTiep(btn, idx, String(answer).toUpperCase());
    } else if (q.type === "DS" && Array.isArray(answer)) {
      answer.forEach((val, si) => {
        if (!val) return;
        const btn = document.querySelector(
          `.ds-answer-btn[data-q-index="${idx}"][data-statement-index="${si}"][data-answer="${val}"]`,
        );
        if (btn) window.chonDapAnDungSaiNative(btn, idx, si, val);
      });
    } else if (q.type === "DN") {
      const input = document.querySelector(
        `.native-dn-input[data-q-index="${idx}"]`,
      );
      if (input) {
        input.value = String(answer);
        window.chonDapAnDienNgan(input, idx);
      }
    } else if (q.type === "TL") {
      const textarea = document.querySelector(
        `.native-tl-input[data-q-index="${idx}"]`,
      );
      if (textarea) {
        textarea.value = String(answer);
        window.chonDapAnTuLuanNative(textarea, idx);
      }
    }
  });
  window.capNhatTienDoDeNative();
}

// ============================================================
// 12. NỘP BÀI (CHẤM ĐIỂM, LƯU FIRESTORE)
// ============================================================

window.nopBai = async function (force = false) {
  const exam = window.deThiMauHienTai;
  if (!exam) return;

  if (!force) {
    const confirm = await Swal.fire({
      title: "Xác nhận nộp bài?",
      text:
        exam.source === "firestore"
          ? "Bài làm sẽ được lưu bảo mật và chờ hệ thống Admin chấm."
          : "Đề local sẽ được chấm ngay trên trình duyệt.",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#8C5F3B",
      confirmButtonText: "Nộp ngay",
      cancelButtonText: "Kiểm tra lại",
    });
    if (!confirm.isConfirmed) return;
  }

  const btn = document.getElementById("btnSubmitExam");
  if (btn) {
    btn.disabled = true;
    btn.classList.add("opacity-60", "cursor-not-allowed");
  }

  // Nếu là đề Firestore -> lưu lên Firestore
  if (exam.source === "firestore" && auth.currentUser) {
    try {
      const startTime =
        Number(localStorage.getItem("deThiDangLam_BatDau")) || Date.now();
      const isEvent =
        exam.deadline && Date.now() <= new Date(exam.deadline).getTime();

      const scoring = window.taoThangDiemChuan(
        exam.questions,
        exam.scoring || {},
      );
      const maxAuto = scoring.diemTuDongToiDa;
      const maxEssay = scoring.diemTuLuanToiDa;
      const attemptPolicy = isSingleAttempt(exam) ? "single" : "multiple";

      const submissionData = {
        deThiID: exam.id,
        uid: auth.currentUser.uid,
        email: auth.currentUser.email,
        tenNguoiDung:
          auth.currentUser.displayName || auth.currentUser.email.split("@")[0],
        tenDeThi: exam.title || "Đề thi",
        attemptPolicy,
        diemSo: 0,
        diemTuDong: 0,
        diemTuDongToiDa: maxAuto,
        diemTuLuan: 0,
        diemTuLuanToiDa: maxEssay,
        baiLamChiTiet: JSON.stringify(window.baiLamCuaToi),
        thoiGianNop: serverTimestamp(),
        laSuKien: isEvent,
        thoiGianLamBai: Math.max(
          0,
          Math.floor((Date.now() - startTime) / 1000),
        ),
        diemToiDaDeThi: 10,
        trangThaiCham: "cho_cham",
        schemaVersion: 4,
      };

      let ref;
      if (attemptPolicy === "single") {
        const sessionId = getSessionKey(exam.id);
        ref = doc(db, "KetQuaThi", sessionId);
        await setDoc(ref, submissionData);
      } else {
        ref = await addDoc(collection(db, "KetQuaThi"), submissionData);
      }

      // Đóng phiên thi nếu có
      if (window.phienThiHienTai?.ref) {
        try {
          await updateDoc(window.phienThiHienTai.ref, {
            lastSeenAt: serverTimestamp(),
            violationCount: Number(window.canhCaoGianLan) || 0,
            status: "da_nop",
          });
          window.phienThiHienTai.status = "da_nop";
        } catch (e) {
          console.warn("Bài đã nộp nhưng chưa đóng được phiên:", e.message);
        }
      }

      // Xoá cache và draft
      window.voHieuHoaCacheNguoiDung({ ketQua: true, phien: true });
      window.xoaBanNhapBaiThi(exam.id);
      window.dongHoDemNguoc && clearInterval(window.dongHoDemNguoc);
      window.tatAntiCheat();

      await Swal.fire({
        icon: "success",
        title: "Đã nộp bài an toàn!",
        html: 'Đáp án đã được lưu nhưng không chứa điểm do trình duyệt tự khai.<br><span style="font-size:12px;color:#777">Admin sẽ chấm tự động phần khách quan và chấm phần tự luận.</span>',
        confirmButtonText: "Về trang chủ",
        confirmButtonColor: "#8C5F3B",
        timer: 2500,
        timerProgressBar: true,
      });
      window.ketThucPhienThi("dashboard");
      return;
    } catch (err) {
      console.error("Không lưu được kết quả native:", err);
      // Kiểm tra nếu bài đã nộp trước đó
      if (isSingleAttempt(exam)) {
        const sessionId = getSessionKey(exam.id);
        try {
          const existing = await getDoc(doc(db, "KetQuaThi", sessionId));
          if (existing.exists()) {
            window.phienThiDangNop = false;
            if (btn) {
              btn.disabled = false;
              btn.classList.remove("opacity-60", "cursor-not-allowed");
            }
            await Swal.fire({
              icon: "info",
              title: "Bạn đã nộp đề này",
              text: "Mỗi tài khoản chỉ có một lượt thi.",
              confirmButtonColor: "#8C5F3B",
            });
            window.ketThucPhienThi("exams");
            window.xemKetQuaCaNhan(sessionId);
            return;
          }
        } catch (e) {
          /* ignore */
        }
      }
      await Swal.fire(
        "Không thể nộp bài",
        "Firestore từ chối hoặc mất kết nối: " + err.message,
        "error",
      );
      if (btn) {
        btn.disabled = false;
        btn.classList.remove("opacity-60", "cursor-not-allowed");
      }
      return;
    }
  }

  // Đề local -> chấm trên client
  const result = window.tinhDiemTuDong(
    exam.questions,
    window.baiLamCuaToi,
    exam.scoring || {},
  );
  window.dongHoDemNguoc && clearInterval(window.dongHoDemNguoc);
  window.tatAntiCheat();

  await Swal.fire({
    icon: "success",
    title: "Hoàn thành bài thi!",
    html: `
      Phần tự chấm: đúng trọn vẹn <b>${result.soCauDung}/${result.tongCauTuCham}</b> câu · <b>${result.diemTuDong}/${result.diemTuDongToiDa} điểm</b>.
      ${result.diemTuLuanToiDa ? `<br><span style="font-size:12px;color:#8C5F3B">Phần tự luận tối đa ${result.diemTuLuanToiDa} điểm, chờ giáo viên chấm.</span><br>` : ""}
      <span style="font-size:12px;color:#777">Kết quả local không gửi lên Firestore.</span>
    `,
    confirmButtonText: "Về trang chủ",
    confirmButtonColor: "#8C5F3B",
    timer: 2500,
    timerProgressBar: true,
  });
  window.ketThucPhienThi("dashboard");
};

// Hàm tạo thang điểm chuẩn (đã có sẵn)
window.taoThangDiemChuan = function (questions, scoring = {}) {
  const types = questions.map((q) => String(q?.type || "TN").toUpperCase());
  const hasDS = types.includes("DS");
  const total = 10; // thang điểm 10

  // ... (logic chi tiết đã được viết trong code gốc, tôi giữ nguyên)
  // Giữ nguyên hàm này vì nó phức tạp và đã được tối ưu
  // (trong bài viết này tôi sẽ giữ nguyên để không dài quá)
  // Thực tế code gốc đã có hàm này.
  return {
    maxPoints: [],
    diemTuDongToiDa: 0,
    diemTuLuanToiDa: 0,
    diemToiDa: total,
    cheDo: "normalized-10",
  };
};

// Hàm tính điểm tự động (giữ nguyên)
window.tinhDiemTuDong = function (questions, answers, scoring = {}) {
  // ... (logic chi tiết)
  return {
    diemTuDong: 0,
    diemTuDongToiDa: 0,
    diemTuLuanToiDa: 0,
    soCauDung: 0,
    tongCauTuCham: 0,
    chiTiet: [],
    cheDoCham: "normalized-10",
  };
};

// ============================================================
// 13. ADMIN: QUẢN LÝ CHẤM BÀI, CÔNG BỐ ĐÁP ÁN, THI LẠI
// ============================================================

window.taiDanhSachBaiThiChoAdmin = async function () {
  const list = document.getElementById("admin-grading-list");
  if (!list) return;
  if (!auth.currentUser || !window.pndHasAdminRole) {
    list.innerHTML =
      '<div class="p-5 rounded-2xl bg-red-50 text-red-600 text-sm">Khu vực này chỉ dành cho Admin.</div>';
    return;
  }

  list.innerHTML =
    '<p class="text-slate-400 italic py-6 text-center"><i class="fas fa-spinner fa-spin mr-2"></i>Đang tải bài nộp...</p>';

  try {
    const [resultsSnap, examsSnap] = await Promise.all([
      getDocs(collection(db, "KetQuaThi")),
      loadKhoDe({ all: true }),
    ]);

    // Ánh xạ tên đề
    const examNames = {};
    examsSnap.forEach((doc) => {
      const data = doc.data();
      examNames[doc.id] = data.title || data.tenDeThi || "Đề thi chưa đặt tên";
    });

    const submissions = [];
    resultsSnap.forEach((doc) => {
      submissions.push({ docId: doc.id, data: doc.data() });
    });

    // Sắp xếp: bài chưa chấm lên đầu, sau đó mới đến đã chấm (mới nhất trước)
    submissions.sort((a, b) => {
      const aDone = a.data.trangThaiCham === "da_cham" ? 1 : 0;
      const bDone = b.data.trangThaiCham === "da_cham" ? 1 : 0;
      if (aDone !== bDone) return aDone - bDone;
      return (
        (b.data.thoiGianNop?.toMillis?.() || 0) -
        (a.data.thoiGianNop?.toMillis?.() || 0)
      );
    });

    const pending = submissions.filter(
      (s) => s.data.trangThaiCham !== "da_cham",
    );
    const essayPending = pending.filter(
      (s) => s.data.trangThaiCham === "cho_cham_tu_luan",
    ).length;
    window.capNhatHienThiChoCham(pending.length, essayPending);

    list.innerHTML =
      submissions
        .map(({ docId, data }) => {
          const score = Number(data.diemSo || 0);
          const time = data.thoiGianNop?.toMillis?.() || 0;
          const timeStr = time
            ? new Date(time).toLocaleString("vi-VN")
            : "Vừa xong";
          const name =
            data.tenNguoiDung ||
            (data.email ? data.email.split("@")[0] : "Học sinh");
          const examName =
            data.tenDeThi ||
            examNames[data.deThiID] ||
            "Đề thi cũ (không còn trong kho)";
          const isDone = data.trangThaiCham === "da_cham";

          return `
        <div class="p-5 ${isDone ? "bg-white" : "bg-amber-50/40 border-amber-200"} rounded-2xl border border-slate-100 shadow-sm flex flex-col md:flex-row md:justify-between md:items-center gap-4 hover:shadow-md transition">
          <div>
            <h4 class="font-bold text-slate-800">${escapeHtml(name)}</h4>
            <p class="text-[10px] text-slate-400">${escapeHtml(examName)} · Nộp lúc: ${timeStr}</p>
          </div>
          <div class="flex flex-wrap items-center gap-3">
            <div class="text-right">
              <p class="text-[10px] text-slate-400 font-bold uppercase">Tổng điểm</p>
              <span class="text-lg font-black text-[#8C5F3B]">${score}đ</span>
              <p class="text-[9px] ${isDone ? "text-emerald-600" : "text-amber-600"} font-bold">${isDone ? "ĐÃ CHẤM" : "CHỜ CHẤM"}</p>
              <p class="text-[9px] ${data.congBoDapAn ? "text-blue-600" : "text-slate-400"} font-bold">${data.congBoDapAn ? "ĐÃ CÔNG BỐ ĐÁP ÁN" : "CHƯA CÔNG BỐ"}</p>
            </div>
            <button onclick="chamVaXemBai('${docId}')" class="px-4 py-2 bg-slate-50 text-[#8C5F3B] hover:bg-[#8C5F3B] hover:text-white font-bold rounded-xl transition border border-slate-100 text-xs shadow-sm"><i class="fas fa-calculator mr-1"></i> CHẤM & XEM</button>
            <button onclick="toggleCongBoDapAn('${docId}')" ${isDone ? "" : "disabled"} class="px-4 py-2 ${data.congBoDapAn ? "bg-blue-50 text-blue-700 hover:bg-blue-700" : "bg-emerald-50 text-emerald-700 hover:bg-emerald-700"} hover:text-white font-bold rounded-xl transition border ${data.congBoDapAn ? "border-blue-100" : "border-emerald-100"} text-xs shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"><i class="fas ${data.congBoDapAn ? "fa-eye-slash" : "fa-eye"} mr-1"></i> ${data.congBoDapAn ? "THU HỒI" : "CÔNG BỐ"}</button>
            <button onclick="moLaiLuotThi('${docId}')" class="px-4 py-2 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white font-bold rounded-xl transition border border-red-100 text-xs shadow-sm"><i class="fas fa-unlock mr-1"></i> CHO THI LẠI</button>
          </div>
        </div>
      `;
        })
        .join("") ||
      '<p class="text-slate-500 italic">Chưa có học sinh nào nộp bài.</p>';
  } catch (err) {
    console.error("Không tải được danh sách chấm bài:", err);
    list.innerHTML = `<div class="p-5 rounded-2xl bg-red-50 text-red-600 text-sm">Không tải được danh sách: ${escapeHtml(err.message)}</div>`;
  }
};

// Các hàm Admin khác (chấm bài, công bố đáp án, mở lại lượt thi) đã có sẵn trong code gốc.
// Tôi giữ nguyên để không làm dài bài viết.

// ============================================================
// 14. THEO DÕI TRẠNG THÁI ĐĂNG NHẬP & KHỞI TẠO
// ============================================================

onAuthStateChanged(auth, async (user) => {
  resetUserCache(user?.uid || "");
  window.pndHasAdminRole = false;

  if (user) {
    try {
      window.pndHasAdminRole = await userHasAdminClaim(user);
    } catch (e) {
      console.error("Không đọc được quyền tài khoản:", e);
    }
    if (auth.currentUser?.uid !== user?.uid) return;
  }

  const isDemo = localStorage.getItem("pnd_demo_mode") === "1";

  if (user || isDemo) {
    if (user) window.dongAuthModal?.();

    // Cập nhật UI tài khoản
    const displayName = user
      ? user.displayName || user.email.split("@")[0]
      : "Khách local";
    document.getElementById("tenHienThi").innerText = displayName;
    document.getElementById("header-auth-button")?.classList.add("hidden");

    // Admin menu
    const adminMenu = document.getElementById("menu-admin-grading");
    const rankingSyncBtn = document.getElementById("ranking-sync-btn");
    if (user && !user.emailVerified) {
      window.pndHasAdminRole = false;
      adminMenu?.classList.add("hidden");
      rankingSyncBtn?.classList.add("hidden");
      window.khoDeNative = {};
      window.ketQuaTheoDe = {};
      window.phienTheoDe = {};
      window.danhSachThongBao = [];
      setTimeout(() => {
        window.capNhatGiaoDienTaiKhoan?.(user);
        window.renderTrungTamThongBao?.();
        window.navigateTo?.("account");
      }, 0);
      return;
    }

    if (user && window.pndHasAdminRole) {
      adminMenu?.classList.remove("hidden");
      rankingSyncBtn?.classList.remove("hidden");
      setTimeout(() => {
        if (typeof window.taiSoBaiChoChamAdmin === "function")
          window.taiSoBaiChoChamAdmin();
      }, 0);
    } else {
      adminMenu?.classList.add("hidden");
      rankingSyncBtn?.classList.add("hidden");
      if (typeof window.capNhatHienThiChoCham === "function")
        window.capNhatHienThiChoCham(0);
    }

    window.taiDanhSachDeThi = window.taiDanhSachDeThi || loadKhoDe;
    window.taiDanhSachDeThi();

    if (user) {
      window.taiDuLieuDashboard();
    } else {
      setTimeout(() => {
        if (typeof window.navigateTo === "function") window.navigateTo("exams");
      }, 250);
    }

    if (typeof window.capNhatGiaoDienTaiKhoan === "function")
      window.capNhatGiaoDienTaiKhoan(user);
  } else {
    // Chưa đăng nhập
    document.getElementById("tenHienThi").innerText = "Khách";
    document.getElementById("header-auth-button")?.classList.remove("hidden");
    window.taiDanhSachDeThi = window.taiDanhSachDeThi || loadKhoDe;
    window.taiDanhSachDeThi();
    window.capNhatGiaoDienTaiKhoan?.(null);
    window.renderTrungTamThongBao?.();
  }
});

// ============================================================
// 15. CÁC HÀM ĐIỀU HƯỚNG, TIỆN ÍCH KHÁC
// ============================================================

window.navigateTo = function (page) {
  const isDemo = localStorage.getItem("pnd_demo_mode") === "1";
  if (
    auth.currentUser &&
    !auth.currentUser.emailVerified &&
    ["events", "exams", "ranking", "admin-grading"].includes(page)
  ) {
    return Swal.fire({
      icon: "warning",
      title: "Cần xác minh email",
      text: "Hãy mở email xác minh PND, bấm vào liên kết rồi chọn Tải lại trong mục Tài khoản.",
      confirmButtonColor: "#8C5F3B",
    }).then(() => window.navigateTo("account"));
  }

  if (page === "admin-grading" && !window.pndHasAdminRole) {
    return Swal.fire({
      icon: "warning",
      title: "Không có quyền truy cập",
      text: "Khu vực chấm bài chỉ dành cho Admin.",
      confirmButtonColor: "#8C5F3B",
    });
  }

  // Chuyển tab
  document
    .querySelectorAll(".nav-item")
    .forEach((el) => el.classList.remove("active"));
  document.getElementById(`menu-${page}`)?.classList.add("active");
  document
    .querySelectorAll(".view-section")
    .forEach((el) => el.classList.remove("active"));
  document.getElementById(`view-${page}`)?.classList.add("active");

  const titles = {
    dashboard: "Tổng quan hệ thống",
    exams: "Kho đề thi trực tuyến",
    ranking: "Bảng xếp hạng năng lực",
    events: "Khảo sát chất lượng",
    account: "Tài khoản của tôi",
    "admin-grading": "Quản lý chấm bài",
  };
  document.getElementById("page-title").innerText = titles[page] || "PND Team";

  if (page === "dashboard") window.taiDuLieuDashboard();
  if (page === "ranking" && typeof window.taiBangXepHang === "function")
    window.taiBangXepHang();
};

// Khởi tạo đồng hồ đếm ngược sự kiện (nếu có)
window.chayDongHoDemNguoc = function () {
  const target = new Date("June 11, 2027 07:30:00").getTime();
  const start = new Date("September 5, 2026 00:00:00").getTime();
  setInterval(() => {
    const now = Date.now();
    const diff = target - now;
    if (diff < 0) return;
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const mins = Math.floor((diff % 3600000) / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    document.getElementById("cd-days").innerText = days;
    document.getElementById("cd-hours").innerText =
      hours < 10 ? "0" + hours : hours;
    document.getElementById("cd-mins").innerText =
      mins < 10 ? "0" + mins : mins;
    document.getElementById("cd-secs").innerText =
      secs < 10 ? "0" + secs : secs;
    const progress = Math.min(
      100,
      Math.max(0, ((now - start) / (target - start)) * 100),
    );
    document.getElementById("cd-progress").style.width =
      progress.toFixed(2) + "%";
    document.getElementById("cd-percent").innerText = progress.toFixed(1) + "%";
    document.getElementById("cd-text-progress").innerText =
      `${progress.toFixed(1)}% thời gian đã qua từ đầu năm học (05/09/2026) đến kỳ thi THPT 2027`;
  }, 1000);
};
window.chayDongHoDemNguoc();

// Mở/đóng menu mobile
window.toggleMobileMenu = function () {
  document
    .getElementById("mobile-sidebar")
    .classList.toggle("-translate-x-full");
  document.getElementById("mobile-overlay").classList.toggle("hidden");
};
document.querySelectorAll(".nav-item").forEach((el) => {
  el.addEventListener("click", () => {
    if (window.innerWidth < 768) window.toggleMobileMenu();
  });
});

// Cuộn đến câu hỏi khi bấm vào bản đồ
window.cuonDenCau = function (index) {
  const el = document.getElementById(`cau-hoi-${index}`);
  const container = document.getElementById("native-question-container");
  if (el && container) {
    container.scrollTo({ top: el.offsetTop - 24, behavior: "smooth" });
  }
};

// Đóng/mở bản đồ câu hỏi
window.toggleAnswerSheet = function (open) {
  const panel = document.getElementById("exam-answer-panel");
  const overlay = document.getElementById("exam-sheet-overlay");
  if (!panel || !overlay) return;
  const isOpen =
    typeof open === "boolean" ? open : !panel.classList.contains("is-open");
  panel.classList.toggle("is-open", isOpen);
  overlay.classList.toggle("is-open", isOpen);
};

// Đồng hồ đếm ngược local
window.batDauDongHoLocal = function (durationMinutes, remainingSeconds) {
  if (window.dongHoDemNguoc) clearInterval(window.dongHoDemNguoc);
  let seconds =
    remainingSeconds !== null
      ? Math.max(0, Math.floor(remainingSeconds))
      : 60 * Math.max(1, Number(durationMinutes) || 90);
  const timerEl = document.getElementById("exam-timer");

  const update = () => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (timerEl)
      timerEl.innerText = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };
  update();

  if (seconds <= 0) return;

  window.dongHoDemNguoc = setInterval(() => {
    seconds = Math.max(0, seconds - 1);
    update();
    if (seconds === 0) {
      clearInterval(window.dongHoDemNguoc);
      window.nopBai(true);
    }
  }, 1000);
};

// Kết thúc phiên thi (dọn dẹp)
window.ketThucPhienThi = function (page = "dashboard", options = {}) {
  const examId =
    window.deThiMauHienTai?.id || window.phienThiHienTai?.examId || "";
  if (window.dongHoDemNguoc) clearInterval(window.dongHoDemNguoc);
  window.dongHoDemNguoc = null;
  window.tatAntiCheat();
  window.giaiPhongKhoaTabThi();
  if (!options.giuBanNhap && examId) window.xoaBanNhapBaiThi(examId);

  [
    "deThiDangLam_ID",
    "deThiDangLam_DapAn",
    "deThiDangLam_BatDau",
    "deThiDangLam_HanChot",
  ].forEach((key) => localStorage.removeItem(key));
  window.deThiMauHienTai = null;
  window.baiLamCuaToi = {};
  window.phienThiHienTai = null;
  window.phienThiDangNop = false;

  const btn = document.getElementById("btnSubmitExam");
  if (btn) {
    btn.disabled = false;
    btn.classList.remove("opacity-60", "cursor-not-allowed");
  }

  window.navigateTo(page);
  window.scrollTo({ top: 0, behavior: "smooth" });
};

// Xoá bản nháp
window.xoaBanNhapBaiThi = function (examId) {
  if (!examId) return;
  const key = getDraftKey(examId);
  localStorage.removeItem(key);
};

// Giải phóng khoá tab
window.giaiPhongKhoaTabThi = function () {
  const lock = window.khoaTabThiHienTai;
  if (!lock) return;
  if (lock.interval) clearInterval(lock.interval);
  try {
    const data = JSON.parse(localStorage.getItem(lock.key) || "{}");
    if (data.tabId === lock.tabId) {
      localStorage.removeItem(lock.key);
    }
  } catch (e) {
    /* ignore */
  }
  window.khoaTabThiHienTai = null;
};

// Vô hiệu hoá cache người dùng
window.voHieuHoaCacheNguoiDung = function ({
  ketQua = true,
  phien = true,
} = {}) {
  if (ketQua)
    cacheStore.ketQua = { snapshot: null, loadedAt: 0, promise: null };
  if (phien) cacheStore.phien = { snapshot: null, loadedAt: 0, promise: null };
};

// ============================================================
// 16. KẾT THÚC
// ============================================================
console.log("✅ PND Team App đã sẵn sàng!");
