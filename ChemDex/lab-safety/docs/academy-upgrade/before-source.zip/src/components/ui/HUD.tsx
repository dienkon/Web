import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useStore, playerCoords } from '../../store/useStore';
import { ProgressRing } from '../../ui/ProgressRing';
import { Keycap } from '../../ui/Controls';
import { Sheet } from '../../ui/Sheet';
import { vi } from '../../i18n/vi';
import {
  Trophy,
  Pause,
  HelpCircle,
  AlertOctagon,
  ChevronRight,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  Hand,
  Navigation,
  Flashlight,
  ShieldCheck
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { getActiveObjective } from '../3d/lab/ObjectiveMarker';
import { WaterDropletsOverlay } from './hud/WaterDropletsOverlay';
import { useLabEquipment } from '../../store/useLabEquipment';
import { SafetyPractice } from './SafetyPractice';
import { isSceneInputBlocked } from '../../systems/input/sceneInput';
import { ToolBar } from './hud/ToolBar';
import { LabMinimapHUD } from './hud/LabMinimapHUD';
import { inputManager } from '../../systems/input/InputManager';
import { dispatchInteractionInput } from '../../systems/input/InteractionBus';

export const HUD: React.FC = () => {
  const equipmentDestination = useLabEquipment(s=>s.destination);
  const currentPhase = useStore((s) => s.currentPhase);
  const score = useStore((s) => s.score);
  const errors = useStore((s) => s.errors);
  const tasks = useStore((s) => s.tasks);
  const completeTask = useStore((s) => s.completeTask);
  const activeErrorBanner = useStore((s) => s.activeErrorBanner);
  const dismissErrorBanner = useStore((s) => s.dismissErrorBanner);
  const activeInteraction = useStore((s) => s.activeInteraction);
  const setShowSettings = useStore((s) => s.setShowSettings);
  const setShowRulesList = useStore((s) => s.setShowRulesList);
  const setActiveRuleDialog = useStore((s) => s.setActiveRuleDialog);
  const waterEffect = useStore((s) => s.waterEffect);
  const isFlashlightOn = useStore((s) => s.isFlashlightOn);
  const toggleFlashlight = useStore((s) => s.toggleFlashlight);

  const [showPractice, setShowPractice] = useState(false);
  const practiceBlocked = useStore(isSceneInputBlocked);
  useEffect(() => {
    if (!showPractice) return;
    useStore.setState(s => ({ sceneModalCount: s.sceneModalCount + 1 }));
    return () => { useStore.setState(s => ({ sceneModalCount: Math.max(0, s.sceneModalCount - 1) })); };
  }, [showPractice]);
  const [showTaskListSheet, setShowTaskListSheet] = useState(false);
  const [scoreDelta, setScoreDelta] = useState<number | null>(null);
  const prevScoreRef = useRef(score);

  // Real-time navigation compass & distance to active 3D objective
  const [navInfo, setNavInfo] = useState<{
    title: string;
    distance: number;
    angleDeg: number;
  } | null>(null);

  useEffect(() => {
    const updateNav = () => {
      const state = useStore.getState();
      if (state.view !== 'game') {
        setNavInfo(null);
        return;
      }
      const activeObj = getActiveObjective(
        state.currentPhase,
        state.tasks,
        state.player.flags
      );
      if (!activeObj) {
        setNavInfo(null);
        return;
      }

      const dx = activeObj.position[0] - playerCoords.position[0];
      const dz = activeObj.position[2] - playerCoords.position[2];
      const dist = Math.hypot(dx, dz);

      const targetAngle = Math.atan2(dx, dz);
      let diff = targetAngle - playerCoords.rotationY;
      diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      const angleDeg = (-diff * 180) / Math.PI;

      setNavInfo({
        title: activeObj.title,
        distance: parseFloat(dist.toFixed(1)),
        angleDeg: Math.round(angleDeg),
      });
    };

    const timer = setInterval(updateNav, 80);
    return () => clearInterval(timer);
  }, []);

  // Auto-dismiss error banner after 4 seconds
  useEffect(() => {
    if (!activeErrorBanner) return;
    const timer = setTimeout(() => {
      dismissErrorBanner();
    }, 4000);
    return () => clearTimeout(timer);
  }, [activeErrorBanner, dismissErrorBanner]);

  // Floating score delta (+5, -8) animation
  useEffect(() => {
    const diff = score - prevScoreRef.current;
    if (diff !== 0) {
      setScoreDelta(diff);
      const timer = setTimeout(() => setScoreDelta(null), 1400);
      prevScoreRef.current = score;
      return () => clearTimeout(timer);
    }
  }, [score]);

  // Active phase title
  const phaseTitle = currentPhase === 1
    ? vi.hud.phase1
    : currentPhase === 2
    ? vi.hud.phase2
    : vi.hud.phase3;

  // Current incomplete task
  const playerFlags = useStore(s => s.player.flags);
  const currentTask = useMemo(() => getActiveObjective(currentPhase, tasks, playerFlags), [equipmentDestination, currentPhase, tasks, playerFlags]);

  const completedCount = tasks.filter((t) => t.completed).length;
  const progressPercent = tasks.length > 0 ? (completedCount / tasks.length) * 100 : 0;

  // Filter tasks belonging to current active phase
  const visiblePhaseTasks = useMemo(() => {
    if (currentPhase === 1) {
      return tasks.filter((t) => [
        'task_talk', 'task_rules', 'task_goggles', 'task_coat', 'task_gloves', 'task_mask', 'task_hair', 'task_shoes'
      ].includes(t.id));
    } else if (currentPhase === 2) {
      return tasks.filter((t) => [
        'task_fire_extinguisher', 'task_chemical_symbols', 'task_inspect_acid', 'task_bandage'
      ].includes(t.id));
    } else {
      return tasks.filter((t) => [
        'task_spill_kit', 'task_spill_neutralize', 'task_spill_wipe', 'task_trash_disposal'
      ].includes(t.id));
    }
  }, [tasks, currentPhase]);

  const handleDevSkip = () => {
    if (currentTask) {
      completeTask(currentTask.id);
    }
  };

  return (
    <div data-ui className="fixed inset-0 pointer-events-none z-30 select-none overflow-hidden p-3 sm:p-5 flex flex-col justify-between font-sans">
      
      {/* ================= TOP SECTION ================= */}
      <div className="w-full flex items-start justify-between gap-3 relative">
        
        {/* Top-Left: Objective Card (Desktop) / Progress Ring & Objective (Mobile) */}
        <div className="pointer-events-auto">
          {/* Desktop Objective Card */}
          <div
            onClick={() => setShowTaskListSheet(true)}
            className="hidden lg:flex items-center gap-3.5 px-4 py-3 hud-panel rounded-2xl cursor-pointer hover:border-cyan-300/50 transition-all shadow-xl active:scale-[0.98]"
          >
            <ProgressRing progress={progressPercent} size={42} strokeWidth={4}>
              <span className="text-[11px] font-bold text-cyan-700">
                {completedCount}/{tasks.length}
              </span>
            </ProgressRing>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-700">
                {vi.hud.objective}
              </span>
              <h4 className="text-sm font-bold text-slate-800 leading-snug line-clamp-1 max-w-[220px]">
                {currentTask ? currentTask.title : 'Đã hoàn thành xuất sắc!'}
              </h4>
            </div>
            <ChevronRight className="w-4 h-4 text-cyan-700/50 ml-1" />
          </div>

          {/* Mobile Compact Objective Pill */}
          <div
            onClick={() => setShowTaskListSheet(true)}
            className="lg:hidden flex items-center gap-2.5 px-3 py-2 hud-panel rounded-full cursor-pointer shadow-lg active:scale-95"
          >
            <ProgressRing progress={progressPercent} size={30} strokeWidth={3}>
              <span className="text-[9px] font-bold text-cyan-700">{completedCount}</span>
            </ProgressRing>
            <span className="text-xs font-bold text-slate-800 max-w-[110px] sm:max-w-[220px] truncate">
              {currentTask ? currentTask.title : 'Hoàn thành!'}
            </span>
          </div>
        </div>

        {/* Top-Center: Phase Pill & Waypoint Compass Guidance */}
        <div className="hud-navigation absolute left-1/2 -translate-x-1/2 top-0 pointer-events-auto flex flex-col items-center gap-1.5">
          <div className="px-4 py-1.5 hud-panel rounded-full text-xs font-extrabold text-cyan-800 shadow-lg flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse shadow-[0_0_12px_#6ee7b7]" />
            <span>{phaseTitle}</span>
          </div>

          {navInfo && (
            <div className="flex items-center gap-2 px-3 py-1 bg-white/95 backdrop-blur-md rounded-full text-[11px] font-bold text-slate-800 border border-cyan-400/40 shadow-lg">
              <div
                className="w-4 h-4 flex items-center justify-center transition-transform duration-100"
                style={{ transform: `rotate(${navInfo.angleDeg}deg)` }}
              >
                <Navigation className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
              </div>
              <span className="text-slate-700 max-w-[170px] sm:max-w-[260px] truncate">
                {navInfo.title}
              </span>
              <span className="font-mono text-[10px] text-cyan-300 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-500/30">
                {navInfo.distance}m
              </span>
            </div>
          )}
        </div>

        {/* Top-Right: Score chip, Dev Skip (only in dev), Pause button */}
        <div className="flex items-center gap-2 pointer-events-auto relative">
          
          {/* Score Chip */}
          <div className="relative">
            <div className="flex items-center gap-2 px-3.5 py-2 hud-panel rounded-full text-xs font-bold text-slate-800 shadow-lg">
              <ShieldCheck className={`w-4 h-4 ${errors === 0 ? 'text-emerald-300' : 'text-rose-300'}`} />
              <Trophy className="w-4 h-4 text-amber-500 shrink-0" />
              <span className="font-mono text-sm font-extrabold text-amber-700">{score}</span>
            </div>

            {/* Rising Animated Score Delta (+5 or -8) */}
            <AnimatePresence>
              {scoreDelta !== null && (
                <motion.div
                  initial={{ opacity: 0, y: 0, scale: 0.8 }}
                  animate={{ opacity: 1, y: -24, scale: 1.15 }}
                  exit={{ opacity: 0, y: -36 }}
                  className={`absolute right-2 -top-1 font-mono text-sm font-black pointer-events-none drop-shadow-md ${
                    scoreDelta > 0 ? 'text-emerald-500' : 'text-rose-600'
                  }`}
                >
                  {scoreDelta > 0 ? `+${scoreDelta}` : scoreDelta}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Dev Skip Button: Strictly gated by import.meta.env.DEV */}
          {Boolean((import.meta as any).env?.DEV) && (
            <button
              onClick={handleDevSkip}
              className="px-2.5 py-1.5 bg-rose-50 border border-rose-300 text-rose-600 hover:bg-rose-100 rounded-full text-[10px] font-mono font-bold uppercase transition-all active:scale-95"
              title="Dev Skip Task"
            >
              DEV: SKIP
            </button>
          )}

          {/* Flashlight Button [F] */}
          <button
            onClick={toggleFlashlight}
            className={`w-10 h-10 rounded-full flex items-center justify-center border shadow-xs active:scale-95 transition-all cursor-pointer ${
              isFlashlightOn
                ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-amber-300/40'
                : 'hud-panel hover:bg-cyan-50 text-slate-600 hover:text-slate-800 border-slate-200'
            }`}
            title="Bật/Tắt Đèn Pin Soi Sáng [F]"
            aria-label="Đèn pin"
          >
            <Flashlight className="w-4 h-4" />
          </button>

          {/* Settings / Pause Button */}
          <button
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 hud-panel hover:bg-cyan-50 rounded-full flex items-center justify-center text-slate-600 hover:text-slate-800 shadow-lg active:scale-95 transition-all"
            aria-label="Cài đặt & Tạm dừng"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ================= ERROR BANNER (Slides from top) ================= */}
      <AnimatePresence>
        {activeErrorBanner && (
          <motion.div
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -80, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            className="fixed top-18 inset-x-4 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-[480px] z-50 pointer-events-auto"
          >
            <div className="bg-white rounded-2xl p-4 shadow-xl border border-red-200 border-l-6 border-l-[var(--danger)] flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-red-100 text-[var(--danger)] flex items-center justify-center shrink-0 mt-0.5">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black uppercase tracking-wider text-[var(--danger)]">
                    {activeErrorBanner.title}
                  </h4>
                  <button
                    onClick={() => {
                      dismissErrorBanner();
                      const rule = useStore.getState().tasks; // trigger handbook
                      setShowRulesList(true);
                    }}
                    className="text-[11px] font-bold text-[var(--primary)] hover:underline ml-2"
                  >
                    {vi.hud.viewRules}
                  </button>
                </div>
                <p className="text-xs text-slate-700 mt-0.5 font-medium leading-relaxed">
                  {activeErrorBanner.consequence}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ================= BOTTOM SECTION ================= */}
      <div className="w-full flex items-end justify-between relative pb-2 sm:pb-3 pointer-events-none">
        
        {/* Bottom-Left: Floating Mobile Joystick (on touch) */}
        <div className="pointer-events-auto">
          <VirtualJoystick />
        </div>

        {/* Bottom-Center: Desktop Interaction Prompt & Key Shortcuts */}
        <div className="hidden lg:flex flex-col items-center pointer-events-auto gap-2 mb-20">
          {activeInteraction && (
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              className="px-5 py-2.5 white-glass rounded-2xl border border-[var(--primary)] shadow-md flex items-center gap-3"
            >
              <div className="flex gap-1.5">
                <Keycap label="E" />
                <Keycap label="Space" />
              </div>
              <span className="text-sm font-bold text-[var(--ink)]">
                {activeInteraction}
              </span>
            </motion.div>
          )}

          {/* Persistent subtle Hotkey Ribbon */}
          <div className="hidden lg:flex px-3.5 py-1.5 rounded-full bg-white/90 backdrop-blur-md text-slate-700 text-[11px] font-semibold flex items-center gap-3 border border-slate-200 shadow-lg">
            <span className="flex items-center gap-1"><span className="text-cyan-400 font-mono font-bold">WASD</span> Di chuyển</span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1"><span className="text-cyan-400 font-mono font-bold">Shift</span> Chạy</span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1"><span className="text-amber-400 font-mono font-bold">E / Space</span> Tương tác</span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1"><span className="text-rose-400 font-mono font-bold">Backspace / Q</span> Cất / Đóng</span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1"><span className="text-cyan-400 font-mono font-bold">Tab</span> Sổ tay</span>
            <span className="text-slate-600">|</span>
            <span className="flex items-center gap-1"><span className="text-cyan-400 font-mono font-bold">1-3</span> Dụng cụ</span>
          </div>
        </div>

        {/* Bottom-Right: Mobile Big 64px Interact Button */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          {/* Quick Rules Handbook Button */}
          <button
            onClick={() => setShowRulesList(true)}
            className="w-11 h-11 white-glass rounded-full flex items-center justify-center text-[var(--primary)] border border-[var(--line)] shadow-sm active:scale-95 transition-all"
            title="Sổ tay an toàn"
          >
            <HelpCircle className="w-5 h-5" />
          </button>

          {/* Big Touch Interact Button */}
          <button
            onClick={dispatchInteractionInput}
            className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full flex flex-col items-center justify-center transition-all duration-150 active:scale-95 shadow-xl select-none ${
              activeInteraction
                ? 'btn-primary-glow text-slate-800 ring-4 ring-cyan-400/40 animate-pulse'
                : 'bg-white/90 text-slate-400 border-2 border-slate-200'
            }`}
          >
            <Hand className="w-6 h-6 mb-0.5" />
            <span className="text-[10px] font-extrabold uppercase tracking-tight text-center px-1 leading-none line-clamp-1">
              {activeInteraction || 'Tương tác'}
            </span>
          </button>
        </div>

      </div>

      {/* ================= TASK LIST SHEET MODAL ================= */}
      <Sheet
        isOpen={showTaskListSheet}
        onClose={() => setShowTaskListSheet(false)}
        title={vi.hud.tasks}
        subtitle={`${phaseTitle} (${completedCount}/${tasks.length} hoàn thành)`}
        maxWidth="max-w-md"
      >
        <div className="space-y-2.5 py-1">
          {visiblePhaseTasks.map((t) => (
            <div
              key={t.id}
              className={`p-3 rounded-2xl border transition-all flex items-center gap-3 ${
                t.completed
                  ? 'bg-slate-50/80 border-slate-200 text-slate-400'
                  : 'bg-white border-[var(--line)] text-[var(--ink)] shadow-xs'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                  t.completed ? 'bg-emerald-500 text-slate-800' : 'border-2 border-slate-300'
                }`}
              >
                {t.completed && <CheckCircle2 className="w-4 h-4" />}
              </div>
              <span className={`text-xs font-bold ${t.completed ? 'line-through opacity-70' : ''}`}>
                {t.title}
              </span>
            </div>
          ))}
        </div>
      </Sheet>

      {/* 2D Architectural Minimap Radar */}
      <LabMinimapHUD />
      <ToolBar />
      <button data-ui onClick={()=>window.dispatchEvent(new Event('lab-open-equipment'))} className="fixed right-4 bottom-40 pointer-events-auto rounded-xl border border-cyan-300 bg-slate-900/95 text-cyan-100 px-4 py-3 text-xs font-bold shadow-lg">🧰 Sổ dụng cụ</button>
      {equipmentDestination&&<button data-ui className="fixed left-1/2 top-24 -translate-x-1/2 pointer-events-auto rounded-xl bg-cyan-950/95 text-cyan-100 px-3 py-2 text-xs" onClick={()=>useLabEquipment.getState().navigate(null)}>Đang dẫn đến: {equipmentDestination.title} • Hủy</button>}
      <button data-ui disabled={practiceBlocked} onClick={() => setShowPractice(true)} className="fixed right-4 bottom-24 pointer-events-auto rounded-xl border border-cyan-300 bg-slate-900/95 text-cyan-100 px-4 py-3 text-xs font-bold shadow-lg disabled:hidden">🧠 Luyện kỹ năng</button>
      {showPractice && <div className="fixed inset-0 z-[1100]"><SafetyPractice onClose={() => setShowPractice(false)} /></div>}

      {/* Screen Water / Chemical Splatter Overlay */}
      <WaterDropletsOverlay active={waterEffect.active} type={waterEffect.type} />

    </div>
  );
};

// ================= Virtual Joystick Component =================
const VirtualJoystick: React.FC = () => {
  const zoneRef = useRef<HTMLDivElement>(null);
  const leftHanded = useStore((state) => state.settings.leftHanded);
  const [visual, setVisual] = useState({
    active: false,
    originX: 0,
    originY: 0,
    knobX: 0,
    knobY: 0,
    sprinting: false,
  });

  const finish = (pointerId: number, target: HTMLDivElement) => {
    if (!inputManager.endJoystick(pointerId)) return;
    if (target.hasPointerCapture(pointerId)) target.releasePointerCapture(pointerId);
    setVisual((current) => ({ ...current, active: false, knobX: 0, knobY: 0, sprinting: false }));
  };

  useEffect(() => () => inputManager.resetPointers(), []);

  return (
    <div
      ref={zoneRef}
      data-ui
      aria-label="Cần điều khiển di chuyển"
      className={`fixed bottom-0 ${leftHanded ? 'right-0' : 'left-0'} h-[58vh] w-[40vw] touch-none select-none pointer-events-auto coarse-only`}
      onPointerDown={(event) => {
        if (event.button !== 0 || !inputManager.beginJoystick(event.pointerId, event.clientX, event.clientY)) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        const rect = event.currentTarget.getBoundingClientRect();
        setVisual({
          active: true,
          originX: event.clientX - rect.left,
          originY: event.clientY - rect.top,
          knobX: 0,
          knobY: 0,
          sprinting: false,
        });
      }}
      onPointerMove={(event) => {
        const next = inputManager.updateJoystick(event.pointerId, event.clientX, event.clientY);
        if (!next) return;
        setVisual((current) => ({
          ...current,
          knobX: next.x,
          knobY: next.y,
          sprinting: next.sprinting,
        }));
      }}
      onPointerUp={(event) => finish(event.pointerId, event.currentTarget)}
      onPointerCancel={(event) => finish(event.pointerId, event.currentTarget)}
    >
      {visual.active && (
        <div
          className={`absolute h-28 w-28 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 shadow-xl backdrop-blur-sm ${visual.sprinting ? 'border-amber-300 bg-amber-300/20' : 'border-cyan-200/70 bg-slate-950/35'}`}
          style={{ left: visual.originX, top: visual.originY }}
        >
          <div className="absolute left-1/2 top-1/2 h-px w-full -translate-x-1/2 bg-white/20" />
          <div className="absolute left-1/2 top-1/2 h-full w-px -translate-y-1/2 bg-white/20" />
          <div
            className={`absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-white shadow-lg ${visual.sprinting ? 'bg-amber-400' : 'bg-gradient-to-tr from-[var(--primary)] to-cyan-400'}`}
            style={{ marginLeft: visual.knobX, marginTop: visual.knobY }}
          >
            <div className="h-3 w-3 rounded-full bg-white/70" />
          </div>
        </div>
      )}
    </div>
  );
};
