import { useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useStore } from '../../store/useStore';
// Adjust pixel cost with hysteresis while preserving the selected Auto preset.
export function AdaptivePerformance() {
  const { setDpr } = useThree();
  const quality = useStore(s => s.settings.graphicsQuality);
  const sample = useRef({ elapsed: 0, frames: 0, dpr: 1, slow: 0, warmup: 3 });
  useFrame((_, dt) => {
    const s = sample.current;
    if (quality !== 'auto' || document.hidden) return;
    if (s.warmup > 0) { s.warmup -= dt; return; }
    if (dt > 0.25) return;
    s.elapsed += dt; s.frames++;
    if (s.elapsed < 2) return;
    const fps = s.frames / s.elapsed;
    s.slow = fps < 54 ? s.slow + 1 : 0;
    if (s.slow >= 2 && s.dpr > 0.65) { s.dpr = Math.max(0.65, s.dpr - 0.15); setDpr(s.dpr); s.slow = 0; }
    s.elapsed = 0; s.frames = 0;
  });
  return null;
}
